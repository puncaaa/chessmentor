"""Тесты анализатора без настоящего Stockfish (движок подменён заглушкой)."""
import chess
import chess.engine

from app.services.chess_analyzer import ChessEngineAnalyzer


def test_mate_already_given_counts_as_win_for_the_mating_side():
    # После мата ход у проигравшего; движок сообщает Mate(-0) с его стороны
    after_mate = chess.engine.PovScore(chess.engine.Mate(-0), chess.BLACK)
    assert ChessEngineAnalyzer.score_to_cp(after_mate, chess.WHITE) == 2000
    assert ChessEngineAnalyzer.score_to_cp(after_mate, chess.BLACK) == -2000


class _FlatEngine:
    """Заглушка движка: любая позиция оценивается как равная."""

    def analyse(self, board, limit):
        return {"score": chess.engine.PovScore(chess.engine.Cp(0), chess.WHITE), "depth": 1}


def test_time_spent_is_measured_per_side():
    pgn = """[Event "?"]

1. e4 { [%clk 0:03:00] } 1... e5 { [%clk 0:02:58] } 2. Nf3 { [%clk 0:02:50] } 2... Nc6 { [%clk 0:02:40] } *
"""
    analyzer = ChessEngineAnalyzer()
    analyzer.engine = _FlatEngine()
    result = analyzer.analyze_game(pgn, student_color=chess.BLACK)
    spent = {m.san: m.time_spent_seconds for m in result.moves_tree}
    assert spent["Nf3"] == 10.0   # 3:00 -> 2:50 на часах белых
    assert spent["Nc6"] == 18.0   # 2:58 -> 2:40 на часах чёрных (раньше считалось от часов белых)
