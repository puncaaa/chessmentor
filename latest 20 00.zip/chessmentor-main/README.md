# ChessMentor

A web app that helps chess coaches track their students' progress. A coach signs in,
adds students with their Lichess / Chess.com usernames, and the app downloads their
games, checks every move with the Stockfish engine and shows:

- **Games**: each game with its mistakes marked `??` (blunder), `?` (mistake) and `?!` (inaccuracy),
  a trainer mode where the student finds the best move on an interactive board, and a replay
  mode with a clickable scoresheet.
- **Progress**: score, average accuracy, accuracy game by game, where mistakes happen
  (opening / middlegame / endgame), weakest tactical themes and the opening repertoire.
- **Reports**: a review for the coach and a plain-language letter for parents (written by
  OpenAI if a key is set, otherwise from data-driven templates), plus PDF downloads.
- **Students**: each coach manages only their own students (name, gender, age, accounts).

The interface is available in **Russian and English** (switch in the sidebar; the choice is
kept in the page address, e.g. `?lang=en`).

## Quick start

```bash
python3 -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt

# Chess engine (needed to analyse games)
brew install stockfish             # macOS; Linux: sudo apt install stockfish

cp .env.example .env               # then check STOCKFISH_PATH in .env
python scripts/seed_demo_coaches.py   # optional demo data
streamlit run app/ui/dashboard.py
```

Open http://localhost:8501. Demo coaches: **Alan** (password `alan123`, 5 students) and
**Aisara** (password `aisara123`, 3 students). The demo students have no chess usernames yet:
add real ones on the **Students** tab, then press **Load and analyze games**.

New coaches register with **I'm a new coach** in the sidebar.

## Configuration (`.env`)

| Setting | Default | Notes |
|---|---|---|
| `DATABASE_URL` | `sqlite:///./chess.db` | PostgreSQL also works: `postgresql://user:pass@host:5432/db`. If it is unreachable the app logs a warning and uses the local SQLite file. |
| `STOCKFISH_PATH` | `/opt/homebrew/bin/stockfish` | Path to the Stockfish binary. Without it games still load, but are not analysed; the sidebar says so and offers to re-check them later. |
| `STOCKFISH_DEPTH` | `12` | Engine depth per move. |
| `OPENAI_API_KEY` | empty | Optional. Only initials of the student are sent to OpenAI, never the full name. |

## Project structure

```
app/
├── core/config.py              Settings from .env
├── db/session.py               Database connection; adds new columns to older databases
├── models/chess.py             Tables: Coach, StudentProfile, StudentChessAccount, Game, ChessErrorEvent
├── schemas/                    Pydantic models for analysis results and reports
├── services/
│   ├── coach_service.py        Coach sign-in, adding / editing / removing students (with validation)
│   ├── chess_sync.py           Downloading games from Lichess and Chess.com
│   ├── game_service.py         Saving games (without duplicates) and analysis results
│   ├── chess_analyzer.py       Stockfish analysis: accuracy, centipawn loss, mistakes, game phase
│   ├── opening_analyzer.py     Opening repertoire: results and early mistakes per opening
│   ├── puzzle_service.py       Lichess puzzle themes matched to the student's mistakes
│   ├── llm_reporter.py         Statistics for reports, coach and parent reports (OpenAI or templates)
│   ├── pdf_generator.py        Parent report PDF
│   └── worksheet_generator.py  A4 puzzle sheet PDF from the student's own mistakes
├── tasks/                      Celery tasks (sync and analysis); the web app runs them in-process
└── ui/
    ├── dashboard.py            Entry point: page setup, sidebar, header, tabs
    ├── i18n.py                 All interface text in Russian and English
    ├── theme.py, styles/       Colours, fonts and CSS
    ├── charts.py               Progress rings and the accuracy chart (SVG)
    ├── components/chessboard/  Interactive board (chessboard.js) with scoresheet
    └── views/                  One module per tab + sidebar
scripts/
├── seed_demo_coaches.py        Demo coaches and students
└── sync_pipeline_check.py      End-to-end check against real Lichess (needs internet + Stockfish; uses a temporary database)
test_*.py                       Unit tests (no internet or Stockfish needed)
```

`migrations/001_initial_schema.sql` is an early PostgreSQL design draft (organisations, roles,
parents). The app itself creates its tables from `app/models/chess.py`, so this file does not
match the current schema.

## Tests

```bash
pytest
```

They cover coach and student management, translations (every key exists in both languages
with the same placeholders), the report templates (no invented claims, no Russian in English
reports) and parts of the engine analysis (using a fake engine).

## Known limitations

- PDF files are generated in Russian only. They need a font with Cyrillic: Arial (macOS, Windows)
  or DejaVu Sans (Linux) is picked up automatically.
- Analysis stops after move 40 (`max_plies=80` in `ChessEngineAnalyzer`), so late endgame mistakes
  are not counted.
- Opening names come from the platforms as-is (usually English).
