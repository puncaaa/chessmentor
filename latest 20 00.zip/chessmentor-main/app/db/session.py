import logging
import os
from contextlib import contextmanager
from sqlalchemy import create_engine, inspect, text
from sqlalchemy.orm import sessionmaker, Session
from app.core.config import settings
from app.models.chess import Base

logger = logging.getLogger(__name__)

DEFAULT_SQLITE_URL = "sqlite:///./chess.db"


def _resolve_database_url() -> str:
    """Адрес базы из DATABASE_URL (.env или переменная окружения).

    SQLite используется как есть. Для PostgreSQL сначала проверяем, что сервер
    отвечает; если нет — переходим на локальный SQLite и пишем об этом в лог,
    а не подменяем адрес молча.
    """
    url = os.getenv("DATABASE_URL") or settings.DATABASE_URL or DEFAULT_SQLITE_URL
    # Приложение работает синхронно, поэтому асинхронный драйвер заменяем обычным
    url = url.replace("postgresql+asyncpg://", "postgresql://")
    if url.startswith("sqlite"):
        return url
    try:
        with create_engine(url, pool_pre_ping=True).connect():
            return url
    except Exception as exc:
        logger.warning("База %s недоступна (%s). Используется локальный SQLite: %s", url, exc, DEFAULT_SQLITE_URL)
        return DEFAULT_SQLITE_URL


sync_db_url = _resolve_database_url()

engine = create_engine(
    sync_db_url,
    connect_args={"check_same_thread": False} if sync_db_url.startswith("sqlite") else {},
    pool_pre_ping=True,
)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, expire_on_commit=False, bind=engine)

# Колонки, добавленные после первой версии схемы. create_all() не меняет
# существующие таблицы, поэтому в старую базу их нужно дописать вручную.
_ADDED_COLUMNS = {
    "student_profiles": {
        "coach_id": "VARCHAR(36) REFERENCES coaches(id) ON DELETE SET NULL",
        "gender": "VARCHAR(10)",
        "age": "INTEGER",
    },
}


def _add_missing_columns():
    """Дописывает новые колонки в уже существующие таблицы (без потери данных)."""
    inspector = inspect(engine)
    with engine.begin() as conn:
        for table, columns in _ADDED_COLUMNS.items():
            if not inspector.has_table(table):
                continue
            existing = {col["name"] for col in inspector.get_columns(table)}
            for name, ddl in columns.items():
                if name not in existing:
                    conn.execute(text(f"ALTER TABLE {table} ADD COLUMN {name} {ddl}"))


def init_db():
    """Создание всех таблиц в базе данных и обновление старой схемы."""
    Base.metadata.create_all(bind=engine)
    _add_missing_columns()

@contextmanager
def get_db_session() -> Session:
    """Контекстный менеджер сессии SQLAlchemy с автоматическим rollback при ошибке."""
    session = SessionLocal()
    try:
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()
