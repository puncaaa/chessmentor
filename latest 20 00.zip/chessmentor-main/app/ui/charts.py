"""SVG-графики и кольца прогресса для дашборда.

Рисуем вручную, а не через Plotly, чтобы управлять анимацией появления
и чтобы графики выглядели частью темы. Всё работает без JavaScript:
подсказки при наведении сделаны на CSS (``.pt:hover``).
"""
import html
from typing import List, Sequence

from app.models.chess import Game
from app.ui import i18n
from app.ui.i18n import t


def short_date(game: Game) -> str:
    """Дата партии: «25 окт» / «Oct 25»."""
    return i18n.short_date(game.played_at)


def ring(value: float, label: str, sublabel: str = "", tone: str = "felt") -> str:
    """Кольцо прогресса 0–100% с числом в центре.

    ``tone`` — имя CSS-переменной цвета дуги (felt, amber, flag).
    Дуга дорисовывается при появлении (анимация в theme.css).
    """
    pct = max(0.0, min(100.0, float(value)))
    radius = 42
    circumference = 2 * 3.14159265 * radius
    filled = circumference * pct / 100
    return f"""
    <div class="ring">
        <svg viewBox="0 0 100 100" role="img" aria-label="{html.escape(label)}: {pct:g}%">
            <circle class="ring-track" cx="50" cy="50" r="{radius}"/>
            <circle class="ring-arc" cx="50" cy="50" r="{radius}"
                style="stroke:var(--{tone}); stroke-dasharray:{filled:.1f} {circumference:.1f}; --ring-len:{filled:.1f};"/>
        </svg>
        <div class="ring-value"><span class="fig">{pct:g}</span><small>%</small></div>
        <div class="ring-text">
            <div class="ring-label">{html.escape(label)}</div>
            <div class="ring-sub">{sublabel}</div>
        </div>
    </div>
    """


def accuracy_timeline(games: Sequence[Game], outcomes: Sequence[str]) -> str:
    """Линия точности по партиям в хронологическом порядке.

    Точки окрашены по результату партии (победа / ничья / поражение),
    пунктир — средняя точность. ``games`` и ``outcomes`` идут параллельно.
    """
    points = [
        (g, o, float(g.accuracy_score))
        for g, o in zip(games, outcomes)
        if g.accuracy_score is not None
    ]
    points.sort(key=lambda p: p[0].played_at or 0)
    if len(points) < 2:
        return f'<div class="lbl">{t("chart.need_two")}</div>'

    width, height = 960, 300
    left, right, top, bottom = 48, 24, 24, 44
    plot_w, plot_h = width - left - right, height - top - bottom

    values = [p[2] for p in points]
    y_min = max(0.0, (min(values) // 10) * 10 - 10)
    y_max = 100.0

    def x_at(i: int) -> float:
        return left + plot_w * i / (len(points) - 1)

    def y_at(v: float) -> float:
        return top + plot_h * (1 - (v - y_min) / (y_max - y_min))

    coords = [(x_at(i), y_at(v)) for i, (_, _, v) in enumerate(points)]
    line = " ".join(f"{'M' if i == 0 else 'L'}{x:.1f},{y:.1f}" for i, (x, y) in enumerate(coords))
    area = f"{line} L{coords[-1][0]:.1f},{top + plot_h} L{coords[0][0]:.1f},{top + plot_h} Z"
    average = sum(values) / len(values)

    # Сетка и подписи оси Y
    grid = []
    step = 10 if (y_max - y_min) <= 50 else 20
    tick = y_min
    while tick <= y_max:
        y = y_at(tick)
        grid.append(f'<line class="grid" x1="{left}" x2="{width - right}" y1="{y:.1f}" y2="{y:.1f}"/>')
        grid.append(f'<text class="axis" x="{left - 10}" y="{y + 4:.1f}" text-anchor="end">{tick:g}%</text>')
        tick += step

    # Подписи дат: не больше ~8, чтобы не наезжали друг на друга
    every = max(1, round(len(points) / 8))
    dates = [
        f'<text class="axis" x="{x:.1f}" y="{height - 14}" text-anchor="middle">{short_date(g)}</text>'
        for i, ((g, _, _), (x, _)) in enumerate(zip(points, coords))
        if i % every == 0 or i == len(points) - 1
    ]

    # Точки с подсказками при наведении
    dots = []
    for i, ((g, outcome, v), (x, y)) in enumerate(zip(points, coords)):
        tip = f"{short_date(g)}, {g.opponent_username}: {t('outcome.' + outcome).lower()}, {v:g}%"
        tip_w = 8 * len(tip) + 24
        tip_x = min(max(x - tip_w / 2, left), width - right - tip_w)
        tip_y = y - 46 if y - 46 > 0 else y + 18
        dots.append(f"""
        <g class="pt" style="--i:{i}">
            <line class="hover-rule" x1="{x:.1f}" x2="{x:.1f}" y1="{top}" y2="{top + plot_h}"/>
            <circle class="hit" cx="{x:.1f}" cy="{y:.1f}" r="18"/>
            <circle class="dot dot-{outcome}" cx="{x:.1f}" cy="{y:.1f}" r="6"/>
            <g class="tip">
                <rect x="{tip_x:.1f}" y="{tip_y:.1f}" width="{tip_w}" height="30" rx="4"/>
                <text x="{tip_x + 12:.1f}" y="{tip_y + 20:.1f}">{html.escape(tip)}</text>
            </g>
        </g>""")

    avg_y = y_at(average)
    return f"""
    <div class="timeline">
        <svg viewBox="0 0 {width} {height}" role="img" aria-label="{t('chart.aria', v=f'{average:.1f}')}">
            <defs>
                <linearGradient id="tl-fill" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stop-color="#4E6E39" stop-opacity="0.22"/>
                    <stop offset="100%" stop-color="#4E6E39" stop-opacity="0"/>
                </linearGradient>
            </defs>
            {''.join(grid)}
            <path class="area" d="{area}" fill="url(#tl-fill)"/>
            <line class="avg" x1="{left}" x2="{width - right}" y1="{avg_y:.1f}" y2="{avg_y:.1f}"/>
            <path class="line" d="{line}" pathLength="1"/>
            {''.join(dates)}
            {''.join(dots)}
        </svg>
        <div class="legend">
            <span><i class="dot-win"></i>{t("outcome.win")}</span>
            <span><i class="dot-draw"></i>{t("outcome.draw")}</span>
            <span><i class="dot-loss"></i>{t("outcome.loss")}</span>
            <span><b class="avg-key"></b>{t("chart.avg", v=f"{average:.1f}")}</span>
        </div>
    </div>
    """


def rating_summary(games: List[Game]) -> str:
    """Текущий рейтинг и изменение с первой партии в базе (для шапки)."""
    rated = sorted((g for g in games if g.student_rating), key=lambda g: g.played_at or 0)
    if not rated:
        return ""
    first, last = rated[0].student_rating, rated[-1].student_rating
    delta = last - first
    if delta > 0:
        trend = f'<span class="delta up">+{delta}</span>'
    elif delta < 0:
        trend = f'<span class="delta down">−{abs(delta)}</span>'
    else:
        trend = f'<span class="delta">{t("head.rating_same")}</span>'
    return f'<div class="rating"><span class="fig">{last}</span><span class="lbl-light">{t("head.rating")}</span>{trend}</div>'
