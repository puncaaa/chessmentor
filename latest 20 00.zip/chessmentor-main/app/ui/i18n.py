"""Переводы интерфейса (русский / английский).

Как пользоваться:
    from app.ui.i18n import t, plural
    t("tab.games")                       -> "Партии" / "Games"
    t("games.key_moments", n=3)          -> "Ключевые моменты: 3"
    plural("games", 5)                   -> "5 партий" / "5 games"

Текущий язык хранится в ``st.session_state["lang"]`` и в адресе страницы
(``?lang=en``), поэтому переживает перезагрузку. Чтобы добавить язык,
допишите третий элемент в каждый кортеж TEXTS и код языка в LANGUAGES.
"""
from typing import Dict, Optional, Tuple

import streamlit as st

LANGUAGES: Dict[str, str] = {"ru": "Русский", "en": "English"}
DEFAULT_LANGUAGE = "ru"
_INDEX = {code: i for i, code in enumerate(LANGUAGES)}

# Ключ -> (русский, английский). Плейсхолдеры в фигурных скобках — для str.format.
TEXTS: Dict[str, Tuple[str, str]] = {
    # ---------- Общее ----------
    "app.subtitle": ("Кабинет тренера", "Coach dashboard"),
    "lang.label": ("Язык", "Language"),
    "tab.games": ("Партии", "Games"),
    "tab.progress": ("Прогресс", "Progress"),
    "tab.reports": ("Отчёты", "Reports"),
    "tab.students": ("Ученики", "Students"),
    "color.white_inst": ("белыми", "White"),
    "color.black_inst": ("чёрными", "Black"),
    "color.white": ("белые", "White"),
    "color.black": ("чёрные", "Black"),
    "outcome.win": ("Победа", "Win"),
    "outcome.draw": ("Ничья", "Draw"),
    "outcome.loss": ("Поражение", "Loss"),
    "severity.blunder": ("Зевок", "Blunder"),
    "severity.mistake": ("Ошибка", "Mistake"),
    "severity.inaccuracy": ("Неточность", "Inaccuracy"),
    "phase.opening": ("Дебют", "Opening"),
    "phase.middlegame": ("Миттельшпиль", "Middlegame"),
    "phase.endgame": ("Эндшпиль", "Endgame"),
    "unit.centipawns": ("сантипешек", "centipawns"),
    "unit.seconds": ("с", "s"),
    "platform.lichess": ("Lichess", "Lichess"),
    "platform.chesscom": ("Chess.com", "Chess.com"),
    "gender.male": ("Мужской", "Male"),
    "gender.female": ("Женский", "Female"),
    "dash": ("—", "—"),

    # ---------- Вход и боковая панель ----------
    "login.title": ("Вход", "Sign in"),
    "login.coach": ("Имя тренера", "Coach name"),
    "login.password": ("Пароль", "Password"),
    "login.submit": ("Войти", "Sign in"),
    "login.wrong_password": ("Неверное имя или пароль. Попробуйте ещё раз.", "Wrong name or password. Please try again."),
    "register.title": ("Я новый тренер", "I'm a new coach"),
    "register.name": ("Имя и фамилия", "Full name"),
    "register.password_help": ("Не короче {n} символов", "At least {n} characters"),
    "register.password_again": ("Пароль ещё раз", "Repeat password"),
    "register.submit": ("Создать аккаунт", "Create account"),
    "register.mismatch": ("Пароли не совпадают.", "The passwords don't match."),
    "register.done": ("Аккаунт создан. Добавьте первого ученика.", "Account created. Now add your first student."),
    "sidebar.coach_role": ("тренер", "coach"),
    "sidebar.logout": ("Выйти", "Sign out"),
    "sidebar.students": ("Ученики: {n}", "Students: {n}"),
    "sidebar.no_students": ("Пока никого нет. Добавьте ученика во вкладке «Ученики».",
                            "No students yet. Add one on the “Students” tab."),
    "sidebar.games_to_load": ("Сколько последних партий загрузить", "How many recent games to load"),
    "sidebar.sync": ("Загрузить и разобрать партии", "Load and analyze games"),
    "sidebar.sync_help": ("Партии скачиваются с платформ и проверяются движком Stockfish. Обычно это занимает до минуты.",
                          "Games are downloaded and checked by the Stockfish engine. This usually takes under a minute."),
    "sidebar.no_accounts": ("У ученика нет привязанных аккаунтов. Добавьте ник Lichess или Chess.com во вкладке «Ученики».",
                            "This student has no linked accounts. Add a Lichess or Chess.com username on the “Students” tab."),
    "sync.spinner": ("Загружаем партии {name} и проверяем их движком…", "Loading {name}'s games and checking them with the engine…"),
    "sync.done": ("Готово за {sec} с. Новых партий: {new}, уже были в базе: {dup}.",
                  "Done in {sec}s. New games: {new}, already saved: {dup}."),
    "sync.no_accounts": ("У ученика нет привязанных аккаунтов.", "This student has no linked accounts."),
    "sync.analysis_failed": ("Партии загружены, но движок не смог проверить {n}. {hint}",
                             "Games were loaded, but the engine couldn't check {n}. {hint}"),
    "engine.missing": ("Stockfish не найден: партии загрузятся без разбора ошибок.",
                       "Stockfish wasn't found: games will load without mistake analysis."),
    "engine.install": ("Установите Stockfish (на Mac: `brew install stockfish`) и укажите путь в STOCKFISH_PATH в файле .env. Сейчас: `{path}`",
                       "Install Stockfish (on a Mac: `brew install stockfish`) and set STOCKFISH_PATH in your .env file. Current: `{path}`"),
    "engine.hint": ("Проверьте, что Stockfish установлен.", "Check that Stockfish is installed."),
    "engine.unchecked": ("Не проверено движком: {n}.", "Not checked by the engine yet: {n}."),
    "engine.recheck": ("Проверить партии движком", "Check games with the engine"),
    "engine.recheck_done": ("Проверено партий: {ok}, не получилось: {failed}.", "Games checked: {ok}, failed: {failed}."),
    "engine.recheck_spinner": ("Проверяем партии движком…", "Checking games with the engine…"),

    # ---------- Шапка ----------
    "welcome.title": ("Кабинет тренера", "Coach dashboard"),
    "welcome.meta": ("Войдите слева, чтобы увидеть своих учеников и их партии.",
                     "Sign in on the left to see your students and their games."),
    "head.no_accounts": ("аккаунты не привязаны", "no accounts linked"),
    "head.games_in_db": ("Партий в базе", "Games saved"),
    "head.coach_empty": ("Добавьте учеников во вкладке «Ученики», и здесь появятся их партии и прогресс.",
                         "Add students on the “Students” tab and their games and progress will appear here."),
    "head.rating": ("рейтинг", "rating"),
    "head.rating_same": ("без изменений", "no change"),

    # ---------- Первые шаги ----------
    "steps.title": ("С чего начать", "Getting started"),
    "steps.add": ("Добавьте ученика во вкладке «Ученики»", "Add a student on the “Students” tab"),
    "steps.link": ("Впишите его ник на Lichess или Chess.com", "Enter their Lichess or Chess.com username"),
    "steps.load": ("Нажмите «Загрузить и разобрать партии» слева", "Press “Load and analyze games” on the left"),
    "steps.done": ("готово", "done"),

    # ---------- Подсказки по терминам ----------
    "help.title": ("Что значат эти цифры?", "What do these numbers mean?"),
    "help.body": (
        "**Точность** показывает, насколько ходы ученика близки к ходам шахматного движка: 100% — все ходы лучшие.\n\n"
        "**Потеря за ход** измеряется в **сантипешках** — сотых долях пешки. Потеря 100 значит, что позиция "
        "в среднем ухудшилась так, будто ученик отдал пешку. Чем меньше число, тем лучше.\n\n"
        "**Знаки ошибок**, как в шахматных книгах: **??** — зевок (грубая ошибка), **?** — ошибка, **?!** — неточность.\n\n"
        "**Цейтнот** — когда на часах осталось очень мало времени и ходы делаются в спешке.",
        "**Accuracy** shows how close the student's moves were to the chess engine's choices: 100% means every move was the best one.\n\n"
        "**Loss per move** is measured in **centipawns**, hundredths of a pawn. A loss of 100 means the position "
        "got worse, on average, as if the student gave away a pawn. Smaller is better.\n\n"
        "**Mistake marks**, as in chess books: **??** is a blunder (a serious error), **?** a mistake, **?!** an inaccuracy.\n\n"
        "**Time trouble** means very little time was left on the clock and moves were rushed.",
    ),

    # ---------- Вкладка «Партии» ----------
    "games.empty_title": ("Партий пока нет", "No games yet"),
    "games.empty_body": ("Выберите ученика в панели слева и нажмите «Загрузить и разобрать партии».",
                         "Pick a student on the left and press “Load and analyze games”."),
    "games.pick": ("Партия", "Game"),
    "games.mode_trainer": ("Найти лучший ход", "Find the best move"),
    "games.mode_replay": ("Просмотр партии", "Replay the game"),
    "games.mode_label": ("Режим доски", "Board mode"),
    "games.played_as": ("Играл {color}, {tc}", "Played {color}, {tc}"),
    "games.no_tc": ("контроль не указан", "no time control"),
    "games.unrated": ("без рейтинга", "unrated"),
    "games.accuracy": ("Точность", "Accuracy"),
    "games.loss_per_move": ("Потеря за ход", "Loss per move"),
    "games.mistakes": ("Ошибки в партии", "Mistakes in this game"),
    "games.clean_title": ("Без серьёзных ошибок", "No serious mistakes"),
    "games.clean_body": ("Движок не нашёл в этой партии зевков и ошибок. Доска свободна: можно разыгрывать любые позиции.",
                         "The engine found no blunders or mistakes in this game. The board is free for you to play any position."),
    "games.key_moments": ("Ключевые моменты: {n}", "Key moments: {n}"),
    "games.move_n": ("Ход {n}.", "Move {n}."),
    "games.theme": ("Тема", "Theme"),
    "games.loss": ("Потеря", "Loss"),
    "games.win_chance": ("Шансы на победу", "Winning chances"),
    "games.time_trouble": ("Цейтнот: {s} с на часах", "Time trouble: {s}s on the clock"),
    "games.clock_left": ("На часах было {s} с", "{s}s left on the clock"),
    "games.show_best": ("Показать лучший ход", "Show the best move"),
    "games.reset": ("Вернуть позицию", "Reset position"),
    "games.drag_hint": ("Перетащите фигуру на доске, чтобы проверить свой ход. Движок сразу оценит его.",
                        "Drag a piece on the board to try your move. The engine will check it right away."),
    "games.practice_theme": ("Решать задачи на эту тему на Lichess", "Practice this theme on Lichess"),
    "games.in_game": ("В партии", "In the game"),
    "games.engine": ("Движок", "Engine"),
    "games.replay_hint": ("Нажмите на ход в бланке или листайте стрелками ← → на клавиатуре. Ошибки отмечены красным.",
                          "Click a move on the scoresheet or use the ← → keys. Mistakes are marked in red."),
    "games.download_sheet": ("Скачать лист задач по всем ошибкам (PDF, A4)", "Download a puzzle sheet from all mistakes (PDF, A4)"),
    "games.pdf_ru_note": ("PDF-файлы пока создаются на русском.", "PDF files are generated in Russian for now."),
    "fb.repeat_title": ("Так и было сыграно в партии: {move}", "That's what was played in the game: {move}"),
    "fb.repeat_body": ("{label}: −{cpl} сантипешек, шансы на победу падают на {drop}%.",
                       "{label}: −{cpl} centipawns, winning chances drop by {drop}%."),
    "fb.repeat_retry": ("Нажмите «Вернуть позицию» и поищите другой ход.", "Press “Reset position” and look for a different move."),
    "fb.best_title": ("Верно: {move}!", "Correct: {move}!"),
    "fb.best_body": ("Это первый выбор движка. Ход снимает угрозы соперника.",
                     "That's the engine's first choice. It deals with the opponent's threats."),
    "fb.shown_title": ("Лучший ход: {move}", "Best move: {move}"),
    "fb.other_title": ("Другой ход: {move}", "A different move: {move}"),
    "fb.other_eval": ("Оценка движка: <b>{score}</b> (глубина {depth}).", "Engine evaluation: <b>{score}</b> (depth {depth})."),
    "fb.no_engine": ("Движок Stockfish не найден, поэтому оценить этот ход не получилось. Проверьте STOCKFISH_PATH в файле .env.",
                     "Stockfish was not found, so this move couldn't be evaluated. Check STOCKFISH_PATH in your .env file."),
    "verdict.mate_for": ("Мат в {n} — форсированный выигрыш!", "Mate in {n}: a forced win!"),
    "verdict.mate_against": ("Теперь у соперника мат в {n}. Это грубый зевок.", "Now the opponent has mate in {n}. That's a serious blunder."),
    "verdict.winning": ("Отличный ход: большой перевес ({score}).", "Excellent move: a big advantage ({score})."),
    "verdict.good": ("Хороший ход ({score}).", "Good move ({score})."),
    "verdict.equal": ("Крепкий ход, позиция примерно равная ({score}).", "Solid move, the position is about equal ({score})."),
    "verdict.inaccuracy": ("Неточность ({score}): перевес упущен.", "Inaccuracy ({score}): the advantage slips away."),
    "verdict.mistake": ("Ошибка ({score}): теряется материал.", "Mistake ({score}): material is lost."),
    "verdict.blunder": ("Грубый зевок ({score}): позиция критическая.", "Blunder ({score}): the position is now critical."),
    "ply.start": ("Начальная позиция", "Starting position"),
    "ply.white_to_move": ("Ход белых", "White to move"),
    "ply.error": ("{glyph} {label}: −{cpl} сантипешек. {theme}", "{glyph} {label}: −{cpl} centipawns. {theme}"),

    # ---------- Вкладка «Прогресс» ----------
    "progress.empty_title": ("Здесь появится статистика", "Statistics will appear here"),
    "progress.empty_body": ("Загрузите хотя бы несколько партий ученика.", "Load at least a few of the student's games."),
    "progress.score": ("Набрано очков", "Score"),
    "progress.score_sub": ("+{w} ={d} −{l} в {games}", "+{w} ={d} −{l} in {games}"),
    "progress.avg_accuracy": ("Средняя точность", "Average accuracy"),
    "progress.acc_strong": ("Высокий уровень", "Strong"),
    "progress.acc_steady": ("Стабильная игра", "Steady"),
    "progress.acc_practice": ("Нужна практика", "Needs practice"),
    "progress.loss_per_move": ("Потеря за ход", "Loss per move"),
    "progress.level_master": ("Уровень мастера", "Master level"),
    "progress.level_cm": ("Уровень кандидата в мастера", "Candidate master level"),
    "progress.level_club": ("Уровень клубного игрока", "Club player level"),
    "progress.time_trouble": ("Ошибок в цейтноте", "Mistakes in time trouble"),
    "progress.out_of": ("из {n} ошибок", "out of {n} mistakes"),
    "progress.no_errors": ("ошибок не найдено", "no mistakes found"),
    "progress.timeline": ("Точность от партии к партии", "Accuracy game by game"),
    "progress.by_phase": ("Где ошибается: по стадиям партии", "Where mistakes happen: by game stage"),
    "progress.mistakes_hover": ("Ошибок", "Mistakes"),
    "progress.by_theme": ("Какие темы подводят", "Weakest tactical themes"),
    "progress.no_tactics": ("Тактических ошибок не найдено.", "No tactical mistakes found."),
    "rep.title": ("Дебютный репертуар", "Opening repertoire"),
    "rep.caption": ("Какие дебюты ученик играет, как в них набирает очки и где теряет позицию в первые 10–15 ходов.",
                    "Which openings the student plays, how they score in them, and where they lose ground in the first 10–15 moves."),
    "rep.holes_title": ("Слабых мест в репертуаре: {n}", "Weak spots in the repertoire: {n}"),
    "rep.holes_body": ("Больше всего внимания требует <b>{name}</b> {color}: {wins}% побед в {games}, потеря в дебюте {acpl} сантипешек за ход.",
                       "<b>{name}</b> as {color} needs the most attention: {wins}% wins in {games}, opening loss of {acpl} centipawns per move."),
    "rep.ok_title": ("Явных пробелов в дебютах нет", "No obvious gaps in the openings"),
    "rep.ok_body": ("В первые 15 ходов серьёзных систематических провалов не видно.", "No serious recurring problems in the first 15 moves."),
    "rep.as_white": ("Белыми ({n})", "As White ({n})"),
    "rep.as_black": ("Чёрными ({n})", "As Black ({n})"),
    "rep.only_weak": ("Только слабые места ({n})", "Weak spots only ({n})"),
    "rep.show": ("Показать дебюты", "Show openings"),
    "rep.none": ("В этой категории дебютов нет.", "No openings in this category."),
    "rep.status_red": ("Слабое место", "Weak spot"),
    "rep.status_amber": ("Стоит разобрать", "Worth reviewing"),
    "rep.status_green": ("Надёжно", "Solid"),
    "rep.plays_as": ("Играет {color}", "Plays it as {color}"),
    "rep.games": ("Партий", "Games"),
    "rep.wins": ("Побед", "Wins"),
    "rep.accuracy": ("Точность в дебюте", "Opening accuracy"),
    "rep.loss": ("потеря {n} за ход", "loses {n} per move"),
    "rep.early": ("Ошибок до 15-го хода", "Mistakes before move 15"),
    "rep.early_blunders": ("из них зевков: {n}", "blunders among them: {n}"),
    "rep.tip_label": ("Совет тренеру.", "Coach tip."),
    "rep.tip_red": ("Разберите с учеником основные планы и типичные пешечные структуры этого дебюта: здесь чаще всего теряются очки.",
                    "Go through the main plans and typical pawn structures of this opening with the student: this is where most points are lost."),
    "rep.tip_amber": ("Посмотрите вместе партии в этом дебюте и найдите, на каком ходу позиция начинает ухудшаться.",
                      "Look through the games in this opening together and find the move where the position starts to slip."),
    "rep.tip_green": ("Дебют разыгрывается уверенно. Можно оставить в репертуаре без изменений.",
                      "The student plays this opening confidently. It can stay in the repertoire as is."),

    # ---------- Вкладка «Отчёты» ----------
    "reports.title": ("Отчёт по партиям", "Game report"),
    "reports.caption": ("Подробный разбор для тренера и понятное письмо для родителей, по одним и тем же партиям.",
                        "A detailed review for the coach and a plain-language letter for parents, based on the same games."),
    "reports.for_coach": ("Для тренера", "For the coach"),
    "reports.for_parents": ("Для родителей", "For parents"),
    "reports.audience": ("Для кого отчёт", "Report audience"),
    "reports.empty_title": ("Отчёт пока не из чего собрать", "Nothing to report yet"),
    "reports.empty_body": ("Сначала загрузите партии ученика в панели слева.", "Load the student's games on the left first."),
    "reports.generate": ("Составить отчёт", "Create report"),
    "reports.spinner": ("Собираем отчёт по партиям…", "Putting the report together…"),
    "reports.download_sheet": ("Скачать лист задач (PDF)", "Download puzzle sheet (PDF)"),
    "reports.download_parent": ("Скачать отчёт для родителей (PDF)", "Download parent report (PDF)"),
    "reports.summary": ("Итог по партиям: {name}", "Summary: {name}"),
    "reports.patterns": ("Повторяющиеся ошибки", "Recurring mistakes"),
    "reports.time": ("Игра в цейтноте", "Play in time trouble"),
    "reports.plan": ("План следующих занятий", "Plan for the next lessons"),
    "reports.homework": ("Домашнее задание", "Homework"),
    "reports.homework_caption": ("Подборки задач Lichess под темы, в которых ученик ошибался.",
                                 "Lichess puzzle sets for the themes where the student made mistakes."),
    "reports.puzzles_n": ("{n} задач", "{n} puzzles"),
    "reports.freq": ("Встретилось {count} раз ({pct}% всех ошибок)", "Seen {count} times ({pct}% of all mistakes)"),
    "reports.freq_basic": ("Базовая профилактика зевков", "Basic blunder prevention"),
    "reports.freq_vision": ("Развитие тактического зрения", "Building tactical vision"),
    "reports.open_puzzles": ("Открыть задачи: {title}", "Open puzzles: {title}"),
    "reports.messenger": ("Текст для мессенджера", "Text for a messenger"),
    "reports.messenger_caption": ("Скопируйте и отправьте себе или коллеге.", "Copy it and send it to yourself or a colleague."),
    "reports.msg_title": ("Разбор партий: {name}", "Game review: {name}"),
    "reports.msg_patterns": ("Повторяющиеся ошибки:", "Recurring mistakes:"),
    "reports.msg_homework": ("Задачи на дом (Lichess):", "Homework puzzles (Lichess):"),
    "reports.msg_plan": ("План занятий:", "Lesson plan:"),
    "reports.week": ("Как прошла неделя: {name}", "How the week went: {name}"),
    "reports.went_well": ("Что получилось", "What went well"),
    "reports.next": ("Над чем работаем дальше", "What we're working on next"),
    "reports.home": ("Как поддержать дома", "How to help at home"),
    "reports.whatsapp": ("Сообщение для WhatsApp", "Message for WhatsApp"),
    "reports.whatsapp_caption": ("Готовый текст, который можно переслать родителям.", "Ready-to-send text for parents."),
    "reports.coach_name": ("Тренерский штаб", "Coaching team"),

    # ---------- Вкладка «Ученики» ----------
    "students.title": ("Мои ученики", "My students"),
    "students.empty_title": ("Список пока пуст", "No students yet"),
    "students.empty_body": ("Заполните форму справа, чтобы добавить первого ученика.", "Fill in the form on the right to add your first student."),
    "students.col_name": ("Ученик", "Student"),
    "students.col_gender": ("Пол", "Gender"),
    "students.col_age": ("Возраст", "Age"),
    "students.col_games": ("Партий", "Games"),
    "students.current_hint": ("Ученик, выбранный слева, выделен. Его партии и прогресс показаны на других вкладках.",
                              "The student selected on the left is highlighted. Their games and progress are on the other tabs."),
    "students.action": ("Действие", "Action"),
    "students.add": ("Добавить ученика", "Add a student"),
    "students.edit": ("Изменить данные", "Edit details"),
    "students.full_name": ("Имя и фамилия", "Full name"),
    "students.gender": ("Пол", "Gender"),
    "students.age": ("Возраст", "Age"),
    "students.age_placeholder": ("лет", "years"),
    "students.lichess_placeholder": ("ник или ссылка lichess.org/@/…", "username or lichess.org/@/… link"),
    "students.chesscom_placeholder": ("ник или ссылка chess.com/member/…", "username or chess.com/member/… link"),
    "students.save": ("Сохранить изменения", "Save changes"),
    "students.added": ("Ученик {name} добавлен.", "{name} has been added."),
    "students.saved": ("Изменения сохранены.", "Changes saved."),
    "students.who": ("Кого изменить", "Student to edit"),
    "students.delete_title": ("Удалить ученика", "Remove student"),
    "students.delete_warning": ("Вместе с учеником удалятся все его партии и разбор ошибок. Отменить это нельзя.",
                                "All of the student's games and mistake analysis will be deleted too. This can't be undone."),
    "students.delete_confirm": ("Да, удалить {name}", "Yes, remove {name}"),
    "students.delete": ("Удалить", "Remove"),
    "students.deleted": ("Ученик {name} удалён.", "{name} has been removed."),

    # ---------- Ошибки ввода (коды из coach_service.ValidationError) ----------
    "err.name_required": ("Введите имя ученика.", "Enter the student's name."),
    "err.gender_invalid": ("Выберите пол из списка.", "Choose a gender from the list."),
    "err.age_range": ("Возраст должен быть от {min} до {max} лет.", "Age must be between {min} and {max}."),
    "err.username_invalid": ("Ник {platform} «{value}» выглядит неправильно. Нужен ник или ссылка на профиль.",
                             "The {platform} username “{value}” doesn't look right. Enter a username or a profile link."),
    "err.account_taken": ("Аккаунт {platform} «{username}» уже привязан к другому ученику.",
                          "The {platform} account “{username}” is already linked to another student."),
    "err.student_not_found": ("Ученик не найден среди ваших учеников.", "This student isn't one of yours."),
    "err.coach_name_required": ("Введите имя тренера.", "Enter the coach's name."),
    "err.password_short": ("Пароль должен быть не короче {n} символов.", "The password must be at least {n} characters long."),
    "err.coach_exists": ("Тренер «{name}» уже зарегистрирован.", "A coach named “{name}” already exists."),

    # ---------- Графики ----------
    "chart.need_two": ("Нужно минимум две партии с оценкой точности, чтобы показать динамику.",
                       "At least two games with an accuracy score are needed to show a trend."),
    "chart.avg": ("средняя точность {v}%", "average accuracy {v}%"),
    "chart.aria": ("Точность по партиям, средняя {v}%", "Accuracy by game, average {v}%"),

    # ---------- Доска (передаётся в компонент) ----------
    "board.loading": ("Загружаем доску…", "Loading the board…"),
    "board.to_move_white": ("Ход белых", "White to move"),
    "board.to_move_black": ("Ход чёрных", "Black to move"),
    "board.check": ("шах", "check"),
    "board.mate_white": ("Мат. Белые выиграли.", "Checkmate. White wins."),
    "board.mate_black": ("Мат. Чёрные выиграли.", "Checkmate. Black wins."),
    "board.draw": ("Ничья", "Draw"),
    "board.first": ("В начало", "Start"),
    "board.prev": ("‹ Назад", "‹ Back"),
    "board.next": ("Вперёд ›", "Next ›"),
    "board.last": ("В конец", "End"),
    "board.of": ("из", "of"),
    "board.sheet": ("Бланк партии", "Scoresheet"),
    "board.sheet_moves": ("ходов: {n}", "{n} moves"),
    "board.sheet_errors": ("ошибок: {n}", "{n} mistakes"),
    "board.seek": ("Перемотка ходов партии", "Move through the game"),
}

# Формы для plural(): русский (1, 2–4, 5+) и английский (1, иначе)
PLURALS: Dict[str, Tuple[Tuple[str, str, str], Tuple[str, str]]] = {
    "games": (("партия", "партии", "партий"), ("game", "games")),
    "years": (("год", "года", "лет"), ("year old", "years old")),
    "moves": (("ход", "хода", "ходов"), ("move", "moves")),
}

# Темы задач Lichess (ключ — slug темы из puzzle_service): (название, описание) по языкам
PUZZLE_THEMES: Dict[str, Tuple[Tuple[str, str], Tuple[str, str]]] = {
    "hangingPiece": (("Защита и взятие висячих фигур", "Привычка проверять, защищена ли каждая фигура, перед тем как сделать ход."),
                     ("Hanging pieces", "The habit of checking that every piece is protected before making a move.")),
    "fork": (("Двойной удар и вилки", "Нападение сразу на две цели."),
             ("Forks", "Attacking two targets at once.")),
    "pin": (("Связка", "Как использовать связанные фигуры соперника."),
            ("Pins", "Using the opponent's pinned pieces.")),
    "skewer": (("Линейный удар", "Нападение на ценную фигуру, за которой стоит другая."),
               ("Skewers", "Attacking a valuable piece to win the one behind it.")),
    "discoveredAttack": (("Вскрытое нападение", "Ход одной фигурой открывает линию атаки другой."),
                         ("Discovered attacks", "Moving one piece to open an attack by another.")),
    "mateIn2": (("Мат в 1–2 хода", "Доводить атаку на короля до мата."),
                ("Mate in 1–2", "Finishing an attack on the king with checkmate.")),
    "backRankMate": (("Слабость последней горизонтали", "Мат ладьёй или ферзём королю, запертому своими пешками."),
                     ("Back-rank weakness", "Mating a king trapped behind its own pawns with a rook or queen.")),
    "short": (("Быстрая короткая тактика", "Точный расчёт, когда времени на часах мало."),
              ("Quick short tactics", "Calculating accurately when there's little time on the clock.")),
    "pawnEndgame": (("Активный король в пешечном эндшпиле", "Вывести короля в центр и создать проходную пешку."),
                    ("Active king in pawn endgames", "Bringing the king to the centre and creating a passed pawn.")),
    "opening": (("Типовые идеи и ловушки в дебюте", "Борьба за центр и безопасное развитие фигур."),
                ("Opening ideas and traps", "Fighting for the centre and developing pieces safely.")),
    "crushing": (("Решающий тактический удар", "Найти форсированное наказание за ошибку соперника."),
                 ("Crushing tactics", "Finding a forcing way to punish the opponent's mistake.")),
    "mix": (("Комбинированная тактика", "Общая тактическая зоркость и аккуратный расчёт."),
            ("Mixed tactics", "General tactical awareness and careful calculation.")),
}


def theme_text(slug: str, lang: Optional[str] = None) -> Tuple[str, str]:
    """(название, описание) темы задач на текущем языке."""
    entry = PUZZLE_THEMES.get(slug, PUZZLE_THEMES["mix"])
    return entry[_INDEX[lang or current_language()]]


MONTHS = {
    "ru": ["янв", "фев", "мар", "апр", "мая", "июн", "июл", "авг", "сен", "окт", "ноя", "дек"],
    "en": ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
}


def current_language() -> str:
    """Язык из состояния сессии; вне Streamlit (тесты, скрипты) — язык по умолчанию."""
    try:
        lang = st.session_state.get("lang", DEFAULT_LANGUAGE)
    except Exception:
        return DEFAULT_LANGUAGE
    return lang if lang in LANGUAGES else DEFAULT_LANGUAGE


def t(key: str, lang: Optional[str] = None, **params) -> str:
    """Перевод по ключу. Неизвестный ключ возвращается как есть, чтобы его было видно."""
    entry = TEXTS.get(key)
    if entry is None:
        return key
    text = entry[_INDEX[lang or current_language()]]
    return text.format(**params) if params else text


def plural(word: str, n: int, lang: Optional[str] = None) -> str:
    """Число с правильной формой слова: «1 партия», «3 партии», «5 партий» / «1 game», «5 games»."""
    ru_forms, en_forms = PLURALS[word]
    if (lang or current_language()) == "en":
        return f"{n} {en_forms[0] if n == 1 else en_forms[1]}"
    if n % 10 == 1 and n % 100 != 11:
        form = ru_forms[0]
    elif 2 <= n % 10 <= 4 and not 12 <= n % 100 <= 14:
        form = ru_forms[1]
    else:
        form = ru_forms[2]
    return f"{n} {form}"


def short_date(value, lang: Optional[str] = None) -> str:
    """«25 окт» / «Oct 25»."""
    if not value:
        return ""
    lang = lang or current_language()
    month = MONTHS[lang][value.month - 1]
    return f"{month} {value.day}" if lang == "en" else f"{value.day} {month}"


def init_language() -> None:
    """Берёт язык из адреса страницы (?lang=en), чтобы выбор переживал перезагрузку."""
    if "lang" not in st.session_state:
        from_url = st.query_params.get("lang", DEFAULT_LANGUAGE)
        st.session_state["lang"] = from_url if from_url in LANGUAGES else DEFAULT_LANGUAGE


def language_switcher() -> None:
    """Переключатель языка; выбор сохраняется в адресе страницы."""
    codes = list(LANGUAGES)
    chosen = st.radio(
        "Язык / Language",
        options=codes,
        index=codes.index(current_language()),
        format_func=LANGUAGES.get,
        horizontal=True,
        label_visibility="collapsed",
        key="lang_switch",
    )
    if chosen != st.session_state.get("lang"):
        st.session_state["lang"] = chosen
        st.query_params["lang"] = chosen
        st.rerun()
