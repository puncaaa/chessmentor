"""Общие помощники для вкладок дашборда: контекст страницы, мелкие HTML-блоки, сообщения."""
import html
from dataclasses import dataclass, field
from typing import Dict, List, Optional

import streamlit as st

from app.models.chess import ChessErrorEvent, Game
from app.services import coach_service
from app.ui.i18n import plural, t


@dataclass
class PageContext:
    """Всё, что нужно вкладкам: кто вошёл, какой ученик выбран и его партии."""
    coach: coach_service.CoachView
    students: List[coach_service.StudentView]
    student: Optional[coach_service.StudentView]
    games: List[Game] = field(default_factory=list)
    errors_by_game: Dict[str, List[ChessErrorEvent]] = field(default_factory=dict)
    all_errors: List[ChessErrorEvent] = field(default_factory=list)

    @property
    def student_name(self) -> str:
        return self.student.full_name if self.student else ""


def render_html(markup: str) -> None:
    """HTML без обработки Markdown (st.html). Для SVG используйте theme.render_svg_html."""
    st.html(markup)


def esc(value) -> str:
    """Экранирование всего, что пришло извне: имена, ники, тексты отчётов."""
    return html.escape(str(value)) if value is not None else ""


def note_box(kind: str, title: str, body: str = "") -> str:
    """Блок-подсказка: kind = 'good' | 'bad' | 'info'. title и body — уже готовый HTML."""
    body_html = f"<div>{body}</div>" if body else ""
    return f'<div class="note-box note-{kind}"><div class="title">{title}</div>{body_html}</div>'


# ---------- Результат партии ----------
def game_outcome(game: Game) -> str:
    """Исход партии с точки зрения ученика: 'win', 'loss' или 'draw'."""
    res = game.result or "*"
    if (game.student_color == "white" and res == "1-0") or (game.student_color == "black" and res == "0-1"):
        return "win"
    if (game.student_color == "white" and res == "0-1") or (game.student_color == "black" and res == "1-0"):
        return "loss"
    return "draw"


_OUTCOME_CSS = {"win": "chip-win", "loss": "chip-loss", "draw": "chip-draw"}


def result_text(game: Game) -> str:
    return (game.result or "*").replace("1/2", "½").replace("-", "–")


def outcome_chip(game: Game) -> str:
    outcome = game_outcome(game)
    return f'<span class="chip {_OUTCOME_CSS[outcome]}">{t("outcome." + outcome)}, {result_text(game)}</span>'


# ---------- Ученик ----------
def age_label(age: Optional[int]) -> str:
    return plural("years", age) if age else ""


def accounts_label(accounts: Dict[str, str]) -> str:
    if not accounts:
        return t("head.no_accounts")
    return ", ".join(f"{t('platform.' + p)}: {esc(u)}" for p, u in accounts.items())


def validation_message(exc: coach_service.ValidationError) -> str:
    """Текст ошибки ввода на текущем языке."""
    return t(f"err.{exc.code}", **exc.params)


# ---------- Сообщения, переживающие st.rerun() ----------
def flash(kind: str, text: str) -> None:
    """kind: 'success' | 'warning' | 'info'. Сообщения копятся до следующего показа."""
    st.session_state.setdefault("flash", []).append((kind, text))


def show_flash() -> None:
    for kind, text in st.session_state.pop("flash", []):
        {"success": st.success, "warning": st.warning}.get(kind, st.info)(text)


def reset_student_state() -> None:
    for key in ("student_id", "cached_coach_report", "cached_parent_report"):
        st.session_state.pop(key, None)


# ---------- Понятные объяснения ----------
def metrics_help() -> None:
    """Раскрывающаяся подсказка: что значат точность, сантипешки и знаки ошибок."""
    with st.expander(t("help.title")):
        st.markdown(t("help.body"))


def getting_started(ctx: "PageContext") -> None:
    """Три шага для нового тренера; выполненные шаги отмечены."""
    has_student = bool(ctx.students)
    has_account = bool(ctx.student and ctx.student.accounts)
    has_games = bool(ctx.games)
    steps = [(t("steps.add"), has_student), (t("steps.link"), has_account), (t("steps.load"), has_games)]
    done_mark = f"<em>{t('steps.done')}</em>"
    items = "".join(
        f'<li class="{"done" if done else ""}"><span>{text}</span>{done_mark if done else ""}</li>'
        for text, done in steps
    )
    render_html(f'<div class="panel steps"><div class="steps-title">{t("steps.title")}</div><ol>{items}</ol></div>')
