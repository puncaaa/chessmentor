"""Вкладка «Отчёты»: разбор для тренера и письмо для родителей, PDF-файлы."""
from typing import Any, Dict, List

import streamlit as st

from app.services.llm_reporter import (
    GameMetricsAggregator, LLMReporterService, describe_period, games_to_aggregator_input,
)
from app.services.pdf_generator import PDFReportGenerator
from app.services.puzzle_service import PuzzleGeneratorService
from app.services.worksheet_generator import WorksheetPDFGenerator
from app.ui.i18n import current_language, t, theme_text
from app.ui.theme import rich_text
from app.ui.views.common import PageContext, note_box, render_html

ROLE_COACH = "coach"
ROLE_PARENT = "parent"


def render(ctx: PageContext) -> None:
    col_title, col_role = st.columns([6, 4])
    with col_title:
        st.markdown(f"### {t('reports.title')}")
        st.caption(t("reports.caption"))
    with col_role:
        role = st.radio(
            t("reports.audience"),
            options=[ROLE_COACH, ROLE_PARENT],
            format_func=lambda r: t("reports.for_coach") if r == ROLE_COACH else t("reports.for_parents"),
            horizontal=True,
            label_visibility="collapsed",
        )

    # В отчёт идут только партии, проверенные движком: за остальные чисел нет
    report_input = games_to_aggregator_input(ctx.games)
    if not report_input:
        render_html(note_box("info", t("reports.empty_title"), t("reports.empty_body")))
        return

    lang = current_language()
    stats = GameMetricsAggregator().aggregate(
        student_name=ctx.student_name,
        period_description=describe_period(ctx.games, lang),
        games_data=report_input,
    )

    # Отчёт, собранный на другом языке, не показываем
    if st.session_state.get("cached_report_lang") != lang:
        st.session_state.pop("cached_coach_report", None)
        st.session_state.pop("cached_parent_report", None)

    c_generate, c_parent_pdf, c_sheet = st.columns(3, gap="medium")
    with c_generate:
        generate = st.button(t("reports.generate"), type="primary", use_container_width=True)
    if ctx.all_errors:
        with c_sheet:
            st.download_button(
                label=t("reports.download_sheet"),
                data=WorksheetPDFGenerator.generate_worksheet(
                    student_name=ctx.student_name, error_events=ctx.all_errors, games=ctx.games, max_puzzles=4,
                ),
                file_name=f"ChessWorksheet_{ctx.student_name.replace(' ', '_')}.pdf",
                mime="application/pdf",
                use_container_width=True,
                key="btn_download_worksheet_reports",
                help=t("games.pdf_ru_note") if lang != "ru" else None,
            )

    if generate:
        reporter = LLMReporterService(language=lang, gender=ctx.student.gender if ctx.student else None)
        with st.spinner(t("reports.spinner")):
            st.session_state["cached_coach_report"] = reporter.generate_coach_report(stats)
            st.session_state["cached_parent_report"] = reporter.generate_parent_report(stats)
            st.session_state["cached_report_lang"] = lang

    coach_report = st.session_state.get("cached_coach_report")
    parent_report = st.session_state.get("cached_parent_report")
    if not coach_report:
        return

    if parent_report:
        with c_parent_pdf:
            st.download_button(
                label=t("reports.download_parent"),
                data=PDFReportGenerator.generate_parent_pdf(report=parent_report, stats=stats, coach_name=t("reports.coach_name", lang="ru")),
                file_name=f"ChessMentor_Report_{parent_report.child_name.replace(' ', '_')}.pdf",
                mime="application/pdf",
                use_container_width=True,
                help=t("games.pdf_ru_note") if lang != "ru" else None,
            )

    st.divider()
    if role == ROLE_COACH:
        _coach_report(coach_report, stats)
    elif parent_report:
        _parent_report(parent_report)


def _recommendations(stats) -> List[Dict[str, Any]]:
    """Подборки задач Lichess с переведёнными названиями и причиной."""
    recs = []
    for rec in PuzzleGeneratorService.generate_recommendations(stats.top_tactical_weaknesses):
        title, description = theme_text(PuzzleGeneratorService.get_theme_info(rec["tag"])["theme"])
        if "count" in rec:
            reason = t("reports.freq", count=rec["count"], pct=rec["percentage"])
        else:
            reason = t("reports.freq_basic") if rec.get("reason") == "basic" else t("reports.freq_vision")
        recs.append({**rec, "title": title, "description": description, "reason_text": reason})
    return recs


def _coach_report(report, stats) -> None:
    render_html(note_box("info", t("reports.summary", name=rich_text(report.student_name)), rich_text(report.executive_summary)))

    st.markdown(f"#### {t('reports.patterns')}")
    patterns_html = "".join(
        f"""
        <div class="pattern">
            <div class="head">
                <span class="title">{rich_text(p.title)}</span>
                <span class="chip chip-loss">{rich_text(p.frequency)}</span>
            </div>
            <p>{rich_text(p.description)}</p>
        </div>
        """
        for p in report.systemic_patterns
    )
    render_html(f'<div class="panel">{patterns_html}</div>')
    render_html(f"""
    <div class="panel">
        <span class="lbl">{t("reports.time")}</span>
        <div style="margin-top:4px; line-height:1.5;">{rich_text(report.time_trouble_verdict)}</div>
    </div>
    """)

    st.markdown(f"#### {t('reports.plan')}")
    render_html('<ol class="lesson-plan">' + "".join(f"<li>{rich_text(x)}</li>" for x in report.next_lessons_plan) + "</ol>")

    st.divider()
    st.markdown(f"#### {t('reports.homework')}")
    st.caption(t("reports.homework_caption"))
    recs = _recommendations(stats)
    for rec in recs:
        render_html(f"""
        <div class="panel homework">
            <div class="panel-row">
                <span class="title">{rec['title']}</span>
                <span class="chip">{t("reports.puzzles_n", n=rec['puzzles_recommended'])}</span>
            </div>
            <div class="muted" style="margin-top:6px; line-height:1.5;">{rec['description']}</div>
            <div class="small" style="margin-top:8px; color:var(--flag);">{rec['reason_text']}</div>
        </div>
        """)
        st.link_button(t("reports.open_puzzles", title=rec["title"]), rec["url"], use_container_width=True)

    st.divider()
    st.markdown(f"#### {t('reports.messenger')}")
    st.caption(t("reports.messenger_caption"))
    lines = [
        t("reports.msg_title", name=report.student_name), "", report.executive_summary, "",
        t("reports.msg_patterns"), *[f"- {p.title} ({p.frequency})" for p in report.systemic_patterns], "",
        t("reports.msg_homework"), *[f"- {r['title']}: {r['url']}" for r in recs], "",
        t("reports.msg_plan"), *[f"- {x}" for x in report.next_lessons_plan],
    ]
    st.code("\n".join(lines), language="text")


def _parent_report(report) -> None:
    render_html(note_box("good", t("reports.week", name=rich_text(report.child_name)), rich_text(report.greeting_and_summary)))

    st.markdown(f"#### {t('reports.went_well')}")
    render_html('<ul class="report-list plus">' + "".join(f"<li>{rich_text(a)}</li>" for a in report.achievements) + "</ul>")

    st.markdown(f"#### {t('reports.next')}")
    render_html('<ul class="report-list growth">' + "".join(f"<li>{rich_text(g)}</li>" for g in report.areas_for_growth) + "</ul>")

    render_html(note_box("info", t("reports.home"), rich_text(report.home_support_advice)))

    st.divider()
    st.markdown(f"#### {t('reports.whatsapp')}")
    st.caption(t("reports.whatsapp_caption"))
    lines = [
        report.greeting_and_summary, "",
        f"{t('reports.went_well')}:", *[f"+ {a}" for a in report.achievements], "",
        f"{t('reports.next')}:", *[f"- {g}" for g in report.areas_for_growth], "",
        f"{t('reports.home')}:", report.home_support_advice,
    ]
    st.code("\n".join(lines), language="text")
