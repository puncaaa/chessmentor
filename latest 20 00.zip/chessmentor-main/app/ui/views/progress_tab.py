"""Вкладка «Прогресс»: итоги, точность по партиям, ошибки по стадиям и темам, дебюты."""
from typing import Dict, List

import plotly.graph_objects as go
import streamlit as st

from app.services.opening_analyzer import OpeningAnalyzerService, OpeningGapInfo
from app.services.puzzle_service import PuzzleGeneratorService
from app.ui.charts import accuracy_timeline, ring
from app.ui.i18n import plural, t, theme_text
from app.ui.theme import PALETTE, PHASES, SANS, phase_name, plotly_layout, render_svg_html
from app.ui.views.common import PageContext, esc, game_outcome, metrics_help, note_box, render_html


def render(ctx: PageContext) -> None:
    if not ctx.games:
        render_html(note_box("info", t("progress.empty_title"), t("progress.empty_body")))
        return

    outcomes = [game_outcome(g) for g in ctx.games]
    _summary(ctx, outcomes)
    metrics_help()

    st.markdown(f"#### {t('progress.timeline')}")
    render_svg_html(accuracy_timeline(ctx.games, outcomes))

    col_phase, col_theme = st.columns(2, gap="large")
    with col_phase:
        _errors_by_phase(ctx)
    with col_theme:
        _errors_by_theme(ctx)

    st.divider()
    _repertoire(ctx)


def _summary(ctx: PageContext, outcomes: List[str]) -> None:
    total = len(ctx.games)
    wins, draws, losses = outcomes.count("win"), outcomes.count("draw"), outcomes.count("loss")
    score_pct = round((wins + 0.5 * draws) / total * 100, 1)

    # Точность и потеря за ход — только по партиям, которые проверил движок
    analysed = [g for g in ctx.games if g.analysis_status == "completed" and g.accuracy_score is not None]
    avg_acc = round(sum(float(g.accuracy_score) for g in analysed) / len(analysed), 1) if analysed else None
    avg_acpl = int(sum(g.acpl or 0 for g in analysed) / len(analysed)) if analysed else None

    score_tone = "felt" if score_pct >= 50 else ("amber" if score_pct >= 35 else "flag")
    score_ring = ring(score_pct, t("progress.score"),
                      t("progress.score_sub", w=wins, d=draws, l=losses, games=plural("games", total)), score_tone)

    if avg_acc is None:
        accuracy_cell = (f'<div class="big-stat"><span class="lbl">{t("progress.avg_accuracy")}</span>'
                         f'<span class="fig">{t("dash")}</span><span class="note">{t("engine.unchecked", n=total)}</span></div>')
    else:
        acc_class, acc_key = (("good", "progress.acc_strong") if avg_acc >= 85 else
                              ("", "progress.acc_steady") if avg_acc >= 75 else ("warn", "progress.acc_practice"))
        accuracy_cell = ring(avg_acc, t("progress.avg_accuracy"),
                             f'<span class="ring-sub {acc_class}">{t(acc_key)}</span>', "felt" if avg_acc >= 75 else "amber")

    if avg_acpl is None:
        loss_fig, loss_note = t("dash"), ""
    else:
        level = ("progress.level_master" if avg_acpl <= 25 else
                 "progress.level_cm" if avg_acpl <= 45 else "progress.level_club")
        loss_fig = f'{avg_acpl} <small>{t("unit.centipawns")}</small>'
        loss_note = t(level)

    tt_errors = sum(1 for e in ctx.all_errors if e.is_time_trouble)
    tt_class = "bad" if tt_errors else "good"
    tt_note = t("progress.out_of", n=len(ctx.all_errors)) if ctx.all_errors else t("progress.no_errors")

    render_svg_html(f"""
    <div class="rings">
        <div>{score_ring}</div>
        <div>{accuracy_cell}</div>
        <div class="big-stat">
            <span class="lbl">{t("progress.loss_per_move")}</span>
            <span class="fig">{loss_fig}</span>
            <span class="note">{loss_note}</span>
        </div>
        <div class="big-stat">
            <span class="lbl">{t("progress.time_trouble")}</span>
            <span class="fig">{tt_errors}</span>
            <span class="note {tt_class}">{tt_note}</span>
        </div>
    </div>
    """)


def _errors_by_phase(ctx: PageContext) -> None:
    st.markdown(f"#### {t('progress.by_phase')}")
    counts = {phase: 0 for phase in PHASES}
    for e in ctx.all_errors:
        if e.phase in counts:
            counts[e.phase] += 1

    fig = go.Figure(go.Bar(
        x=[phase_name(p) for p in counts],
        y=list(counts.values()),
        marker=dict(color=PALETTE["felt"], cornerradius=3, line=dict(width=0)),
        width=0.5,
        text=list(counts.values()),
        textposition="outside",
        textfont=dict(color=PALETTE["ink"], family=SANS, size=13),
        cliponaxis=False,
        hovertemplate=f"<b>%{{x}}</b><br>{t('progress.mistakes_hover')}: %{{y}}<extra></extra>",
    ))
    layout = plotly_layout()
    layout["xaxis"].update(showgrid=False, tickfont=dict(color=PALETTE["ink"], size=13, family=SANS))
    layout["yaxis"].update(showgrid=True, dtick=1 if max(counts.values()) <= 6 else None)
    fig.update_layout(**layout)
    st.plotly_chart(fig, use_container_width=True, config={"displayModeBar": False})


def _errors_by_theme(ctx: PageContext) -> None:
    st.markdown(f"#### {t('progress.by_theme')}")
    counts: Dict[str, int] = {}
    for e in ctx.all_errors:
        title, _ = theme_text(PuzzleGeneratorService.get_theme_info(e.tactical_tag or "tactical_blunder")["theme"])
        counts[title] = counts.get(title, 0) + 1
    if not counts:
        st.caption(t("progress.no_tactics"))
        return

    # По возрастанию: самая частая тема окажется наверху горизонтального графика
    ordered = sorted(counts.items(), key=lambda item: item[1])
    labels, values = [k for k, _ in ordered], [v for _, v in ordered]
    top = max(values)
    fig = go.Figure(go.Bar(
        x=values,
        y=labels,
        orientation="h",
        marker=dict(color=[PALETTE["flag"] if v == top else PALETTE["rule"] for v in values], cornerradius=3),
        text=values,
        textposition="outside",
        textfont=dict(color=PALETTE["ink"], family=SANS, size=12),
        cliponaxis=False,
        hovertemplate=f"<b>%{{y}}</b><br>{t('progress.mistakes_hover')}: %{{x}}<extra></extra>",
    ))
    layout = plotly_layout(height=max(220, 44 * len(labels) + 40))
    layout["xaxis"].update(showgrid=False, showticklabels=False)
    layout["yaxis"].update(showgrid=False, tickfont=dict(color=PALETTE["ink"], size=12, family=SANS))
    fig.update_layout(**layout)
    st.plotly_chart(fig, use_container_width=True, config={"displayModeBar": False})


# ---------------------------------------------------------------------------
# Дебютный репертуар
# ---------------------------------------------------------------------------
_STATUS_STYLE = {
    "red": ("status-hole", "chip-loss", "rep.status_red", "rep.tip_red"),
    "amber": ("status-review", "chip-warn", "rep.status_amber", "rep.tip_amber"),
    "green": ("status-ok", "chip-win", "rep.status_green", "rep.tip_green"),
}


def _color_word(color: str) -> str:
    return t("color.white_inst") if color == "white" else t("color.black_inst")


def _repertoire(ctx: PageContext) -> None:
    st.markdown(f"### {t('rep.title')}")
    st.caption(t("rep.caption"))
    result = OpeningAnalyzerService.analyze_repertoire(games=ctx.games, student_name=ctx.student_name)

    if result.repertoire_holes:
        top = result.repertoire_holes[0]
        body = t("rep.holes_body", name=esc(top.name), color=_color_word(top.color), wins=f"{top.win_rate:g}",
                 games=plural("games", top.games_count), acpl=top.opening_acpl if top.opening_acpl is not None else t("dash"))
        render_html(note_box("bad", t("rep.holes_title", n=len(result.repertoire_holes)), body))
    else:
        render_html(note_box("good", t("rep.ok_title"), t("rep.ok_body")))

    choices = {
        "white": (t("rep.as_white", n=len(result.white_openings)), result.white_openings),
        "black": (t("rep.as_black", n=len(result.black_openings)), result.black_openings),
        "weak": (t("rep.only_weak", n=len(result.repertoire_holes)), result.repertoire_holes),
    }
    default = "white" if result.white_openings else ("black" if result.black_openings else "weak")
    choice = st.radio(
        t("rep.show"),
        options=list(choices),
        index=list(choices).index(default),
        format_func=lambda key: choices[key][0],
        horizontal=True,
        label_visibility="collapsed",
    )
    openings = choices[choice][1]
    if not openings:
        st.caption(t("rep.none"))
        return
    for opening in openings:
        _opening_card(opening)


def _opening_card(op: OpeningGapInfo) -> None:
    card_cls, chip_cls, status_key, tip_key = _STATUS_STYLE.get(op.status_color, _STATUS_STYLE["green"])
    wr_color = "var(--felt)" if op.win_rate >= 50 else ("var(--amber)" if op.win_rate >= 40 else "var(--flag)")
    err_color = ("var(--flag)" if op.early_blunders_count else
                 "var(--amber)" if op.early_errors_count else "var(--felt)")
    accuracy = f"{op.opening_accuracy:g}%" if op.opening_accuracy is not None else t("dash")
    loss = t("rep.loss", n=op.opening_acpl) if op.opening_acpl is not None else ""

    render_html(f"""
    <div class="panel opening {card_cls}">
        <div class="panel-row">
            <div>
                <span class="chip chip-eco">{esc(op.eco)}</span>
                <span class="name">&nbsp;{esc(op.name)}</span>
                <div class="lbl" style="margin-top:4px;">{t("rep.plays_as", color=_color_word(op.color))}</div>
            </div>
            <span class="chip {chip_cls}">{t(status_key)}</span>
        </div>
        <div class="stat-row">
            <div>
                <span class="lbl">{t("rep.games")}</span>
                <span class="fig">{op.games_count}</span>
                <span class="wdl"><span class="w">+{op.wins}</span> ={op.draws} <span class="l">−{op.losses}</span></span>
            </div>
            <div>
                <span class="lbl">{t("rep.wins")}</span>
                <span class="fig" style="color:{wr_color};">{op.win_rate:g}%</span>
            </div>
            <div>
                <span class="lbl">{t("rep.accuracy")}</span>
                <span class="fig">{accuracy}</span>
                <span class="lbl">{loss}</span>
            </div>
            <div>
                <span class="lbl">{t("rep.early")}</span>
                <span class="fig" style="color:{err_color};">{op.early_errors_count}</span>
                <span class="lbl">{t("rep.early_blunders", n=op.early_blunders_count)}</span>
            </div>
        </div>
        <div class="tip"><b>{t("rep.tip_label")}</b> {t(tip_key)}</div>
    </div>
    """)
