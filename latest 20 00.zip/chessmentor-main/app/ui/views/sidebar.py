"""Боковая панель: язык, вход тренера, список учеников, загрузка партий."""
import time
from dataclasses import dataclass
from typing import List, Optional

import streamlit as st
from sqlalchemy import select

from app.core.config import settings
from app.db.session import get_db_session
from app.models.chess import Game
from app.services import coach_service
from app.services.chess_analyzer import engine_available
from app.tasks.analysis_tasks import analyze_game_task
from app.tasks.sync_tasks import sync_student_games
from app.ui.i18n import language_switcher, plural, t
from app.ui.views.common import esc, flash, render_html, reset_student_state, validation_message


@dataclass
class SidebarState:
    coach: Optional[coach_service.CoachView]
    students: List[coach_service.StudentView]
    student: Optional[coach_service.StudentView]


def render_sidebar() -> SidebarState:
    coach: Optional[coach_service.CoachView] = st.session_state.get("coach")
    students: List[coach_service.StudentView] = []
    student: Optional[coach_service.StudentView] = None

    with st.sidebar:
        render_html(f"""
        <div class="brand">
            <div class="brand-mark"><span></span><span></span><span></span><span></span></div>
            <div>
                <div class="brand-name">ChessMentor</div>
                <div class="brand-sub">{t("app.subtitle")}</div>
            </div>
        </div>
        """)
        language_switcher()
        st.divider()

        if not coach:
            _login_forms()
        else:
            students = coach_service.list_students(coach.id)
            student = _coach_panel(coach, students)

    return SidebarState(coach=coach, students=students, student=student)


def _login_forms() -> None:
    st.subheader(t("login.title"))
    with st.form("login"):
        name = st.text_input(t("login.coach"))
        password = st.text_input(t("login.password"), type="password")
        if st.form_submit_button(t("login.submit"), type="primary", use_container_width=True):
            logged_in = coach_service.authenticate_by_name(name, password)
            if logged_in:
                st.session_state["coach"] = logged_in
                reset_student_state()
                st.rerun()
            st.error(t("login.wrong_password"))

    with st.expander(t("register.title")):
        with st.form("register"):
            new_name = st.text_input(t("register.name"))
            new_password = st.text_input(
                t("login.password"), type="password",
                help=t("register.password_help", n=coach_service.MIN_PASSWORD_LENGTH),
            )
            new_password2 = st.text_input(t("register.password_again"), type="password")
            if st.form_submit_button(t("register.submit"), use_container_width=True):
                if new_password != new_password2:
                    st.error(t("register.mismatch"))
                else:
                    try:
                        st.session_state["coach"] = coach_service.create_coach(new_name, new_password)
                        reset_student_state()
                        flash("success", t("register.done"))
                        st.rerun()
                    except coach_service.ValidationError as exc:
                        st.error(validation_message(exc))


def _coach_panel(coach: coach_service.CoachView, students: List[coach_service.StudentView]) -> Optional[coach_service.StudentView]:
    coach_col, logout_col = st.columns([3, 2], vertical_alignment="center")
    with coach_col:
        render_html(f'<div class="coach-name">{esc(coach.full_name)}</div><div class="lbl">{t("sidebar.coach_role")}</div>')
    with logout_col:
        if st.button(t("sidebar.logout"), use_container_width=True):
            st.session_state.pop("coach", None)
            reset_student_state()
            st.rerun()

    st.subheader(t("sidebar.students", n=len(students)))
    if not students:
        st.caption(t("sidebar.no_students"))
        return None

    by_id = {s.id: s for s in students}
    ids = list(by_id)
    if st.session_state.get("student_id") not in by_id:
        st.session_state["student_id"] = ids[0]
    chosen_id = st.radio(
        t("tab.students"),
        options=ids,
        index=ids.index(st.session_state["student_id"]),
        format_func=lambda sid: by_id[sid].full_name + (f" ({by_id[sid].age})" if by_id[sid].age else ""),
        label_visibility="collapsed",
    )
    if chosen_id != st.session_state["student_id"]:
        st.session_state.pop("cached_coach_report", None)
        st.session_state.pop("cached_parent_report", None)
    st.session_state["student_id"] = chosen_id
    student = by_id[chosen_id]

    st.divider()
    _sync_controls(student)
    return student


def _sync_controls(student: coach_service.StudentView) -> None:
    if not engine_available():
        st.warning(t("engine.missing"))
        st.caption(t("engine.install", path=settings.STOCKFISH_PATH))

    games_count = st.slider(t("sidebar.games_to_load"), min_value=3, max_value=10, value=3)
    if st.button(t("sidebar.sync"), use_container_width=True, type="primary", disabled=not student.accounts):
        _run_sync(student, games_count)
    st.caption(t("sidebar.sync_help") if student.accounts else t("sidebar.no_accounts"))

    # Партии, которые движок ещё не проверил (например, Stockfish не был установлен)
    unchecked = _unchecked_game_ids(student.id)
    if unchecked:
        st.caption(t("engine.unchecked", n=len(unchecked)))
        if st.button(t("engine.recheck"), use_container_width=True, disabled=not engine_available()):
            _recheck(unchecked)


def _run_sync(student: coach_service.StudentView, games_count: int) -> None:
    with st.spinner(t("sync.spinner", name=student.full_name)):
        st.session_state.pop("cached_coach_report", None)
        st.session_state.pop("cached_parent_report", None)
        started = time.perf_counter()
        res = sync_student_games(student_id=student.id, max_games=games_count)
        elapsed = time.perf_counter() - started

    if res.get("status") == "no_accounts":
        flash("warning", t("sync.no_accounts"))
    else:
        flash("success", t("sync.done", sec=f"{elapsed:.1f}", new=res.get("new_games", 0), dup=res.get("skipped_duplicates", 0)))
        failed = len(_unchecked_game_ids(student.id, statuses=("failed",)))
        if failed:
            flash("warning", t("sync.analysis_failed", n=plural("games", failed), hint=t("engine.hint")))
    st.rerun()


def _unchecked_game_ids(student_id: str, statuses=("pending", "failed")) -> List[str]:
    with get_db_session() as session:
        return list(session.execute(
            select(Game.id).where(Game.student_profile_id == student_id, Game.analysis_status.in_(statuses))
        ).scalars().all())


def _recheck(game_ids: List[str]) -> None:
    ok = failed = 0
    with st.spinner(t("engine.recheck_spinner")):
        for game_id in game_ids:
            result = analyze_game_task.apply(args=[game_id]).result or {}
            if result.get("status") == "completed":
                ok += 1
            else:
                failed += 1
    flash("success" if not failed else "warning", t("engine.recheck_done", ok=ok, failed=failed))
    st.rerun()
