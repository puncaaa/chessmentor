"""Вкладка «Ученики»: список учеников тренера, добавление, изменение и удаление."""
from typing import Optional

import streamlit as st

from app.services import coach_service
from app.ui.i18n import t
from app.ui.views.common import (
    PageContext, esc, flash, note_box, render_html, reset_student_state, validation_message,
)

ACTION_ADD = "add"
ACTION_EDIT = "edit"


def render(ctx: PageContext) -> None:
    roster_col, form_col = st.columns([7, 5], gap="large")
    with roster_col:
        _roster(ctx)
    with form_col:
        actions = [ACTION_ADD, ACTION_EDIT] if ctx.students else [ACTION_ADD]
        action = st.radio(
            t("students.action"),
            options=actions,
            format_func=lambda a: t("students.add") if a == ACTION_ADD else t("students.edit"),
            horizontal=True,
            label_visibility="collapsed",
        )
        if action == ACTION_ADD:
            _add_form(ctx)
        else:
            _edit_form(ctx)


def _roster(ctx: PageContext) -> None:
    st.markdown(f"### {t('students.title')}")
    if not ctx.students:
        render_html(note_box("info", t("students.empty_title"), t("students.empty_body")))
        return

    def gender(value: Optional[str]) -> str:
        return t(f"gender.{value}") if value in coach_service.GENDERS else t("dash")

    rows = "".join(
        f"""
        <tr class="{'is-current' if ctx.student and s.id == ctx.student.id else ''}">
            <td class="name">{esc(s.full_name)}</td>
            <td>{gender(s.gender)}</td>
            <td class="num">{s.age or t('dash')}</td>
            <td>{esc(s.accounts.get('lichess', t('dash')))}</td>
            <td>{esc(s.accounts.get('chesscom', t('dash')))}</td>
            <td class="num">{s.games_count}</td>
        </tr>"""
        for s in ctx.students
    )
    render_html(f"""
    <div class="roster-wrap"><table class="roster">
        <thead><tr>
            <th>{t("students.col_name")}</th><th>{t("students.col_gender")}</th><th>{t("students.col_age")}</th>
            <th>Lichess</th><th>Chess.com</th><th class="num">{t("students.col_games")}</th>
        </tr></thead>
        <tbody>{rows}</tbody>
    </table></div>
    """)
    st.caption(t("students.current_hint"))


def _student_form(form_key: str, student: Optional[coach_service.StudentView] = None) -> Optional[dict]:
    """Форма данных ученика. Возвращает введённые значения после нажатия кнопки."""
    genders = list(coach_service.GENDERS)
    with st.form(form_key, clear_on_submit=False):
        full_name = st.text_input(t("students.full_name"), value=student.full_name if student else "")
        col_gender, col_age = st.columns(2)
        with col_gender:
            gender = st.radio(
                t("students.gender"),
                options=genders,
                index=genders.index(student.gender) if student and student.gender in genders else None,
                format_func=lambda g: t(f"gender.{g}"),
                horizontal=True,
            )
        with col_age:
            age = st.number_input(
                t("students.age"),
                min_value=coach_service.MIN_AGE,
                max_value=coach_service.MAX_AGE,
                value=student.age if student else None,
                step=1,
                placeholder=t("students.age_placeholder"),
            )
        lichess = st.text_input("Lichess", value=student.accounts.get("lichess", "") if student else "",
                                placeholder=t("students.lichess_placeholder"))
        chesscom = st.text_input("Chess.com", value=student.accounts.get("chesscom", "") if student else "",
                                 placeholder=t("students.chesscom_placeholder"))
        label = t("students.save") if student else t("students.add")
        if st.form_submit_button(label, type="primary", use_container_width=True):
            return {"full_name": full_name, "gender": gender, "age": age, "lichess": lichess, "chesscom": chesscom}
    return None


def _add_form(ctx: PageContext) -> None:
    # Новый ключ формы после успешного сохранения даёт пустую форму;
    # при ошибке ключ тот же, и введённые данные не теряются.
    version = st.session_state.get("add_form_version", 0)
    values = _student_form(f"add_student_{version}")
    if not values:
        return
    try:
        new_id = coach_service.save_student(ctx.coach.id, **values)
    except coach_service.ValidationError as exc:
        st.error(validation_message(exc))
        return
    st.session_state["student_id"] = new_id
    st.session_state["add_form_version"] = version + 1
    flash("success", t("students.added", name=" ".join(values["full_name"].split())))
    st.rerun()


def _edit_form(ctx: PageContext) -> None:
    by_id = {s.id: s for s in ctx.students}
    default_id = ctx.student.id if ctx.student else ctx.students[0].id
    edit_id = st.selectbox(
        t("students.who"),
        options=list(by_id),
        index=list(by_id).index(default_id),
        format_func=lambda sid: by_id[sid].full_name,
    )
    values = _student_form(f"edit_student_{edit_id}", by_id[edit_id])
    if values:
        try:
            coach_service.save_student(ctx.coach.id, student_id=edit_id, **values)
            flash("success", t("students.saved"))
            st.rerun()
        except coach_service.ValidationError as exc:
            st.error(validation_message(exc))

    with st.expander(t("students.delete_title")):
        st.caption(t("students.delete_warning"))
        name = by_id[edit_id].full_name
        confirm = st.checkbox(t("students.delete_confirm", name=name), key=f"confirm_delete_{edit_id}")
        if st.button(t("students.delete"), disabled=not confirm, key=f"delete_{edit_id}"):
            coach_service.delete_student(ctx.coach.id, edit_id)
            reset_student_state()
            flash("success", t("students.deleted", name=name))
            st.rerun()
