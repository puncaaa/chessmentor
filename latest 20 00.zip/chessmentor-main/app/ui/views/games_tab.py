"""Вкладка «Партии»: сводка по партии, тренажёр ошибки и просмотр партии с бланком."""
import io
from typing import Any, Dict, List, Optional

import chess
import chess.pgn
import streamlit as st

from app.models.chess import ChessErrorEvent, Game
from app.services.chess_analyzer import ChessEngineAnalyzer
from app.services.puzzle_service import PuzzleGeneratorService
from app.services.worksheet_generator import WorksheetPDFGenerator
from app.ui.components.chessboard_component import render_interactive_chessboard
from app.ui.i18n import current_language, short_date, t, theme_text
from app.ui.theme import figurine, phase_name, severity_glyph, severity_label, severity_mark
from app.ui.views.common import (
    PageContext, esc, getting_started, metrics_help, note_box, outcome_chip, render_html, result_text,
)

MODE_TRAINER = "trainer"
MODE_REPLAY = "replay"


def render(ctx: PageContext) -> None:
    if not ctx.games:
        getting_started(ctx)
        return

    col_pick, col_mode = st.columns([5, 7], gap="large", vertical_alignment="bottom")
    with col_pick:
        by_id = {g.id: g for g in ctx.games}
        game_id = st.selectbox(
            t("games.pick"),
            options=list(by_id),
            format_func=lambda gid: f"{short_date(by_id[gid].played_at)}: {by_id[gid].opponent_username}, {result_text(by_id[gid])}",
        )
        game = by_id[game_id]
    with col_mode:
        mode = st.radio(
            t("games.mode_label"),
            options=[MODE_TRAINER, MODE_REPLAY],
            format_func=lambda m: t("games.mode_trainer") if m == MODE_TRAINER else t("games.mode_replay"),
            horizontal=True,
            label_visibility="collapsed",
        )

    _game_strip(game)
    metrics_help()

    errors = ctx.errors_by_game.get(game.id, [])
    if mode == MODE_TRAINER:
        _trainer(game, errors)
    else:
        _replay(game, errors)

    if ctx.all_errors:
        st.download_button(
            label=t("games.download_sheet"),
            data=_worksheet(ctx),
            file_name=f"ChessWorksheet_{ctx.student_name.replace(' ', '_')}.pdf",
            mime="application/pdf",
            key="btn_download_worksheet_games",
            help=t("games.pdf_ru_note") if current_language() != "ru" else None,
        )


def _worksheet(ctx: PageContext) -> bytes:
    return WorksheetPDFGenerator.generate_worksheet(
        student_name=ctx.student_name, error_events=ctx.all_errors, games=ctx.games, max_puzzles=4,
    )


# ---------------------------------------------------------------------------
# Сводка по выбранной партии
# ---------------------------------------------------------------------------
def _game_strip(game: Game) -> None:
    color = t("color.white_inst") if game.student_color == "white" else t("color.black_inst")
    analysed = game.analysis_status == "completed" and game.accuracy_score is not None
    acc_val = float(game.accuracy_score) if analysed else None
    accuracy = (
        f'<span class="fig">{acc_val:g}%</span><div class="meter"><i style="width:{min(100.0, acc_val)}%"></i></div>'
        if analysed else f'<span class="fig">{t("dash")}</span>'
    )
    loss = (
        f'<span class="fig">{game.acpl or 0} <small class="unit">{t("unit.centipawns")}</small></span>'
        if analysed else f'<span class="fig">{t("dash")}</span>'
    )
    marks = (
        severity_mark("blunder", game.blunders_count, with_label=False)
        + severity_mark("mistake", game.mistakes_count, with_label=False)
        + severity_mark("inaccuracy", game.inaccuracies_count, with_label=False)
        if analysed else f'<span class="lbl">{t("dash")}</span>'
    )
    render_html(f"""
    <div class="game-strip">
        <div>
            <div class="panel-row">
                <span class="lbl">{t("games.played_as", color=color, tc=esc(game.time_control or t("games.no_tc")))}</span>
                {outcome_chip(game)}
            </div>
            <div class="opponent">
                {esc(game.opponent_username)}
                <span class="rating">{game.opponent_rating or t("games.unrated")}</span>
            </div>
        </div>
        <div><span class="lbl">{t("games.accuracy")}</span>{accuracy}</div>
        <div><span class="lbl">{t("games.loss_per_move")}</span>{loss}</div>
        <div><span class="lbl">{t("games.mistakes")}</span><div class="marks">{marks}</div></div>
    </div>
    """)


# ---------------------------------------------------------------------------
# Тренажёр: позиция перед ошибкой, ученик ищет лучший ход
# ---------------------------------------------------------------------------
def _trainer(game: Game, errors: List[ChessErrorEvent]) -> None:
    col_board, col_side = st.columns([7, 5], gap="large")
    error: Optional[ChessErrorEvent] = None

    # Правая колонка заполняется первой: выбранная ошибка определяет позицию на доске.
    with col_side:
        if not errors:
            render_html(note_box("good", t("games.clean_title"), t("games.clean_body")))
        else:
            by_id = {e.id: e for e in errors}
            error_id = st.selectbox(
                t("games.key_moments", n=len(errors)),
                options=list(by_id),
                format_func=lambda eid: (
                    f"{t('games.move_n', n=by_id[eid].move_number)} {figurine(by_id[eid].played_move_san)}"
                    f"{severity_glyph(by_id[eid].severity)}  (−{by_id[eid].centipawn_loss})"
                ),
            )
            error = by_id[error_id]
            _error_card(error)

    with col_board:
        if error is None:
            render_interactive_chessboard(
                fen=chess.STARTING_FEN, orientation=game.student_color, allow_moves=True,
                labels=board_labels(), key=f"free_board_{game.id}",
            )
            return
        _trainer_board(game, error)

    with col_side:
        _trainer_controls(error)


def _error_card(error: ChessErrorEvent) -> None:
    theme_title, _ = theme_text(PuzzleGeneratorService.get_theme_info(error.tactical_tag or "tactical_blunder")["theme"])
    clock = float(error.clock_remaining_seconds) if error.clock_remaining_seconds is not None else None
    if clock is not None and error.is_time_trouble:
        time_note = f'<span class="chip chip-loss">{t("games.time_trouble", s=f"{clock:g}")}</span>'
    elif clock is not None:
        time_note = f'<span class="lbl">{t("games.clock_left", s=f"{clock:g}")}</span>'
    else:
        time_note = ""
    drop = round(float(error.win_rate_drop or 0) * 100, 1)
    render_html(f"""
    <div class="panel">
        <div class="panel-row">
            {severity_mark(error.severity)}
            <span class="lbl">{phase_name(error.phase)}</span>
        </div>
        <div style="margin-top:12px; line-height:1.5;">
            <span class="lbl">{t("games.theme")}</span><br><b>{theme_title}</b>
        </div>
        <div class="stat-row">
            <div>
                <span class="lbl">{t("games.loss")}</span>
                <span class="fig" style="color:var(--flag);">−{error.centipawn_loss}</span>
                <span class="lbl">{t("unit.centipawns")}</span>
            </div>
            <div>
                <span class="lbl">{t("games.win_chance")}</span>
                <span class="fig" style="color:var(--amber);">−{drop:g}%</span>
            </div>
        </div>
        <div style="margin-top:12px;">{time_note}</div>
    </div>
    """)


def _trainer_board(game: Game, error: ChessErrorEvent) -> None:
    err_id = error.id
    # Новая ошибка — начинаем с исходной позиции
    if st.session_state.get("current_error_view_id") != err_id:
        st.session_state["current_error_view_id"] = err_id
        st.session_state[f"fen_{err_id}"] = error.fen_before
        st.session_state[f"feedback_{err_id}"] = None
        st.session_state[f"anim_{err_id}"] = False

    move_event = render_interactive_chessboard(
        fen=st.session_state.get(f"fen_{err_id}", error.fen_before),
        orientation=game.student_color,
        allow_moves=True,
        animate_best_move=st.session_state.get(f"anim_{err_id}", False),
        best_move_uci=error.best_move_uci,
        labels=board_labels(),
        key=f"drag_board_{game.id}_{err_id}",
    )
    if not move_event or move_event.get("event") != "move_played":
        return
    # Компонент повторно присылает последнее событие при каждой перерисовке
    ts_key = f"last_ts_{err_id}"
    if move_event.get("timestamp") == st.session_state.get(ts_key):
        return
    st.session_state[ts_key] = move_event.get("timestamp")
    st.session_state[f"fen_{err_id}"] = move_event.get("fen_after")
    st.session_state[f"anim_{err_id}"] = False
    st.session_state[f"feedback_{err_id}"] = _feedback_for_move(game, error, move_event)
    st.rerun()


def _feedback_for_move(game: Game, error: ChessErrorEvent, event: Dict[str, Any]) -> Dict[str, str]:
    """Что сказать ученику про его ход: повтор ошибки, лучший ход или оценка движка."""
    uci, san = event.get("uci"), event.get("san")
    if uci == error.played_move_uci or san == error.played_move_san:
        _, description = theme_text(PuzzleGeneratorService.get_theme_info(error.tactical_tag or "tactical_blunder")["theme"])
        drop = round(float(error.win_rate_drop or 0) * 100, 1)
        body = (
            f"<p>{t('fb.repeat_body', label=severity_label(error.severity), cpl=error.centipawn_loss, drop=f'{drop:g}')}</p>"
            f"<p>{description}</p><p>{t('fb.repeat_retry')}</p>"
        )
        return {"type": "bad", "title": t("fb.repeat_title", move=figurine(error.played_move_san) + severity_glyph(error.severity)), "body": body}

    if uci == error.best_move_uci or san == error.best_move_san:
        return {"type": "good", "title": t("fb.best_title", move=figurine(error.best_move_san)), "body": t("fb.best_body")}

    student_color = chess.WHITE if game.student_color == "white" else chess.BLACK
    res = ChessEngineAnalyzer.quick_evaluate_position(fen=event.get("fen_after"), relative_color=student_color)
    title = t("fb.other_title", move=figurine(san))
    if not res.get("ok"):
        return {"type": "info", "title": title, "body": f"<p>{t('fb.no_engine')}</p>"}
    verdict = t(f"verdict.{res['verdict']}", score=res["score_formatted"], n=res.get("mate_moves"))
    body = f"<p>{t('fb.other_eval', score=res['score_formatted'], depth=res['depth'])}</p><p>{verdict}</p>"
    return {"type": "info", "title": title, "body": body}


def _trainer_controls(error: ChessErrorEvent) -> None:
    err_id = error.id
    c_best, c_reset = st.columns(2)
    with c_best:
        if st.button(t("games.show_best"), type="primary", use_container_width=True, key=f"btn_best_{err_id}"):
            st.session_state[f"anim_{err_id}"] = True
            st.session_state[f"feedback_{err_id}"] = {
                "type": "good", "title": t("fb.shown_title", move=figurine(error.best_move_san)), "body": "",
            }
            st.rerun()
    with c_reset:
        if st.button(t("games.reset"), use_container_width=True, key=f"btn_reset_{err_id}"):
            st.session_state[f"fen_{err_id}"] = error.fen_before
            st.session_state[f"anim_{err_id}"] = False
            st.session_state[f"feedback_{err_id}"] = None
            st.rerun()

    feedback = st.session_state.get(f"feedback_{err_id}")
    if feedback:
        render_html(note_box(feedback["type"], feedback["title"], feedback["body"]))
        render_html(f"""
        <div class="versus">
            <div class="played"><span class="lbl">{t("games.in_game")}</span><br><span class="san">{figurine(error.played_move_san)}</span></div>
            <div class="best"><span class="lbl">{t("games.engine")}</span><br><span class="san">{figurine(error.best_move_san)}</span></div>
        </div>
        """)
    else:
        st.caption(t("games.drag_hint"))

    url = PuzzleGeneratorService.get_theme_info(error.tactical_tag or "tactical_blunder")["url"]
    st.link_button(t("games.practice_theme"), url, use_container_width=True)


# ---------------------------------------------------------------------------
# Просмотр партии: доска + бланк записи
# ---------------------------------------------------------------------------
def _replay(game: Game, errors: List[ChessErrorEvent]) -> None:
    plies = parse_game_plies(game.pgn, errors)
    render_interactive_chessboard(
        fen=plies[0]["fen"] if plies else chess.STARTING_FEN,
        orientation=game.student_color,
        allow_moves=False,
        plies=plies,
        initial_ply=0,
        labels=board_labels(),
        key=f"walk_board_{game.id}",
    )
    st.caption(t("games.replay_hint"))


def parse_game_plies(pgn_str: str, error_events: List[ChessErrorEvent]) -> List[Dict[str, Any]]:
    """Все полуходы партии с позицией (FEN) и подписью для навигации по доске.

    Ошибки сопоставляются по номеру полухода, а не по самому ходу: один и тот же
    ход (например, ♘f3) может встретиться в партии несколько раз.
    """
    if not pgn_str:
        return []
    game = chess.pgn.read_game(io.StringIO(pgn_str))
    if not game:
        return []

    errors_by_ply = {e.ply_number: e for e in error_events}
    board = game.board()
    plies = [{
        "ply": 0, "san": t("ply.start"), "notation": "", "glyph": "", "uci": "", "fen": board.fen(),
        "move_number": 0, "is_white": True, "eval_text": t("ply.white_to_move"), "is_error": False,
    }]

    for ply_idx, node in enumerate(game.mainline(), start=1):
        move = node.move
        san = figurine(node.san())
        is_white = board.turn == chess.WHITE
        move_num = board.fullmove_number
        board.push(move)

        err = errors_by_ply.get(ply_idx)
        if err:
            theme_title, _ = theme_text(PuzzleGeneratorService.get_theme_info(err.tactical_tag or "tactical_blunder")["theme"])
            eval_text = t("ply.error", glyph=severity_glyph(err.severity), label=severity_label(err.severity),
                          cpl=err.centipawn_loss, theme=theme_title)
        elif ply_idx <= 14:
            eval_text = phase_name("opening")
        elif ply_idx <= 40:
            eval_text = phase_name("middlegame")
        else:
            eval_text = phase_name("endgame")

        plies.append({
            "ply": ply_idx,
            "san": f"{move_num}. {san}" if is_white else f"{move_num}… {san}",
            "notation": san,
            "glyph": severity_glyph(err.severity) if err else "",
            "uci": move.uci(),
            "fen": board.fen(),
            "move_number": move_num,
            "is_white": is_white,
            "eval_text": eval_text,
            "is_error": bool(err),
        })
    return plies


def board_labels() -> Dict[str, str]:
    """Подписи для JavaScript-компонента доски на текущем языке."""
    keys = ["loading", "to_move_white", "to_move_black", "check", "mate_white", "mate_black", "draw",
            "first", "prev", "next", "last", "of", "sheet", "sheet_moves", "sheet_errors", "seek"]
    labels = {key: t(f"board.{key}") for key in keys}
    labels.update(white=t("color.white"), black=t("color.black"))
    return labels
