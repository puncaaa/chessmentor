"""ChessMentor: веб-приложение для шахматного тренера (Streamlit).

Запуск из корня проекта:
    streamlit run app/ui/dashboard.py

Этот файл только собирает страницу: тема, язык, боковая панель, шапка и
вкладки. Содержимое каждой вкладки — в модулях app/ui/views/.
"""
import os
import sys
from typing import Dict, List

import streamlit as st
from sqlalchemy import select

# Корень проекта в sys.path, чтобы работал импорт app.* при запуске через streamlit
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../..")))

# Задачи Celery выполняются прямо внутри приложения (без отдельного воркера и Redis)
from app.tasks.celery_app import celery_app

celery_app.conf.update(
    task_always_eager=True,
    task_eager_propagates=True,
    broker_url="memory://",
    result_backend="cache+memory://",
)

from app.db.session import get_db_session, init_db
from app.models.chess import ChessErrorEvent, Game
from app.ui.charts import rating_summary
from app.ui.i18n import init_language, t
from app.ui.theme import inject_theme
from app.ui.views import games_tab, progress_tab, reports_tab, students_tab
from app.ui.views.common import PageContext, accounts_label, age_label, esc, render_html, show_flash
from app.ui.views.sidebar import render_sidebar

st.set_page_config(page_title="ChessMentor", page_icon="♞", layout="wide", initial_sidebar_state="expanded")
inject_theme()
init_db()
init_language()


def load_games(student_id: str) -> PageContext:
    """Партии ученика (новые сверху) и найденные в них ошибки."""
    with get_db_session() as session:
        games: List[Game] = list(session.execute(
            select(Game).where(Game.student_profile_id == student_id).order_by(Game.played_at.desc())
        ).scalars().all())
        errors: List[ChessErrorEvent] = list(session.execute(
            select(ChessErrorEvent)
            .where(ChessErrorEvent.student_profile_id == student_id)
            .order_by(ChessErrorEvent.ply_number.asc())
        ).scalars().all()) if games else []

    by_game: Dict[str, List[ChessErrorEvent]] = {}
    for err in errors:
        by_game.setdefault(err.game_id, []).append(err)
    return PageContext(coach=None, students=[], student=None, games=games, errors_by_game=by_game, all_errors=errors)


def page_header(ctx: PageContext) -> None:
    if ctx.student:
        details = [d for d in (age_label(ctx.student.age), accounts_label(ctx.student.accounts)) if d]
        render_html(f"""
        <div class="page-head">
            {rating_summary(ctx.games)}
            <h1>{esc(ctx.student.full_name)}</h1>
            <div class="meta">{'; '.join(details)}. {t("head.games_in_db")}: <b>{len(ctx.games)}</b></div>
        </div>
        """)
    else:
        render_html(f"""
        <div class="page-head">
            <h1>{esc(ctx.coach.full_name)}</h1>
            <div class="meta">{t("head.coach_empty")}</div>
        </div>
        """)


def main() -> None:
    state = render_sidebar()

    if not state.coach:
        render_html(f"""
        <div class="page-head">
            <h1>{t("welcome.title")}</h1>
            <div class="meta">{t("welcome.meta")}</div>
        </div>
        """)
        return

    ctx = load_games(state.student.id) if state.student else PageContext(coach=None, students=[], student=None)
    ctx.coach, ctx.students, ctx.student = state.coach, state.students, state.student

    page_header(ctx)
    show_flash()

    tab_games, tab_progress, tab_reports, tab_students = st.tabs(
        [t("tab.games"), t("tab.progress"), t("tab.reports"), t("tab.students")]
    )
    with tab_games:
        games_tab.render(ctx)
    with tab_progress:
        progress_tab.render(ctx)
    with tab_reports:
        reports_tab.render(ctx)
    with tab_students:
        students_tab.render(ctx)


main()
