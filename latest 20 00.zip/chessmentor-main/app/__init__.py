"""ChessMentor: progress tracking for chess coaches."""
