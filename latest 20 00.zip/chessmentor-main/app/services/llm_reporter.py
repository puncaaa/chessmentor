import os
import json
import logging
from typing import List, Dict, Any, Optional
from collections import Counter

from app.schemas.chess import GamePhase, ErrorSeverity, GameAnalysisResult, AnalyzedMove
from app.schemas.reports import (
    AggregatedStudentStats,
    PhaseBreakdown,
    TimeManagementStats,
    CoachReport,
    ParentReport,
    SystemicPattern,
    HomeworkRecommendation,
)
from app.core.config import settings

logger = logging.getLogger(__name__)


class GameMetricsAggregator:
    """
    Сервис агрегации пула партий ученика за период.
    Рассчитывает объективные шахматные и поведенческие метрики
    без передачи сырых PGN в LLM.
    """

    @staticmethod
    def aggregate(
        student_name: str,
        period_description: str,
        games_data: List[Dict[str, Any]],
    ) -> AggregatedStudentStats:
        """
        games_data: список словарей с ключами:
            - "analysis": GameAnalysisResult
            - "student_color": "white" | "black"
            - "result": "1-0" | "0-1" | "1/2-1/2"
            - "opponent_username": str (optional)
            - "opponent_rating": int (optional)
        """
        if not games_data:
            raise ValueError("Список партий для агрегации пуст.")

        total_games = len(games_data)
        wins = 0
        losses = 0
        draws = 0

        white_stats = {"wins": 0, "losses": 0, "draws": 0}
        black_stats = {"wins": 0, "losses": 0, "draws": 0}

        total_accuracy = 0.0
        total_acpl = 0

        opening_blunders = 0
        middlegame_blunders = 0
        endgame_blunders = 0
        total_inaccuracies = 0
        total_mistakes = 0
        total_blunders = 0

        all_tactical_tags: List[str] = []
        critical_error_samples: List[Dict[str, Any]] = []

        # Тайм-менеджмент
        total_student_moves = 0
        moves_under_15s = 0
        blunders_under_15s = 0
        move_times: List[float] = []
        blunder_times: List[float] = []

        for item in games_data:
            analysis: GameAnalysisResult = item["analysis"]
            color = item.get("student_color", "white").lower()
            res = item.get("result", "")

            # Расчет побед/поражений
            is_win = (color == "white" and res == "1-0") or (color == "black" and res == "0-1")
            is_loss = (color == "white" and res == "0-1") or (color == "black" and res == "1-0")
            is_draw = res in ("1/2-1/2", "0.5-0.5", "draw")

            if is_win:
                wins += 1
                if color == "white":
                    white_stats["wins"] += 1
                else:
                    black_stats["wins"] += 1
            elif is_loss:
                losses += 1
                if color == "white":
                    white_stats["losses"] += 1
                else:
                    black_stats["losses"] += 1
            else:
                draws += 1
                if color == "white":
                    white_stats["draws"] += 1
                else:
                    black_stats["draws"] += 1

            total_accuracy += analysis.accuracy_score
            total_acpl += analysis.acpl
            total_inaccuracies += analysis.inaccuracies_count
            total_mistakes += analysis.mistakes_count
            total_blunders += analysis.blunders_count

            # Анализ ходов и ошибок
            for move in analysis.moves_tree:
                if not move.is_student_move:
                    continue

                total_student_moves += 1
                if move.clock_remaining_seconds is not None:
                    if move.clock_remaining_seconds < 15.0:
                        moves_under_15s += 1

                if move.time_spent_seconds is not None:
                    move_times.append(move.time_spent_seconds)

                if move.severity == ErrorSeverity.BLUNDER:
                    if move.phase == GamePhase.OPENING:
                        opening_blunders += 1
                    elif move.phase == GamePhase.MIDDLEGAME:
                        middlegame_blunders += 1
                    elif move.phase == GamePhase.ENDGAME:
                        endgame_blunders += 1

                    if move.is_time_trouble:
                        blunders_under_15s += 1

                    if move.time_spent_seconds is not None:
                        blunder_times.append(move.time_spent_seconds)

                if move.tactical_tag:
                    all_tactical_tags.append(move.tactical_tag.value)

            for err in analysis.errors:
                if len(critical_error_samples) < 5 and err.severity == ErrorSeverity.BLUNDER:
                    critical_error_samples.append({
                        "move_number": err.move_number,
                        "played_move": err.san,
                        "best_move": err.best_move_san,
                        "centipawn_loss": err.centipawn_loss,
                        "win_rate_drop_pct": round(err.win_rate_drop * 100, 1),
                        "phase": err.phase.value,
                        "tag": err.tactical_tag.value if err.tactical_tag else "tactical_blunder",
                        "time_spent": err.time_spent_seconds,
                        "time_remaining": err.clock_remaining_seconds,
                        "fen_before": err.fen_before,
                    })

        # Агрегирование тегов
        tag_counts = Counter(all_tactical_tags)
        total_tagged = len(all_tactical_tags) or 1
        top_tactical_weaknesses = [
            {
                "tag": tag,
                "count": count,
                "percentage": round((count / total_tagged) * 100, 1),
            }
            for tag, count in tag_counts.most_common(5)
        ]

        # Тайм-менеджмент метрики
        moves_under_15s_rate = (
            round((moves_under_15s / total_student_moves) * 100, 1)
            if total_student_moves
            else 0.0
        )
        blunders_in_time_trouble_rate = (
            round((blunders_under_15s / total_blunders) * 100, 1)
            if total_blunders
            else 0.0
        )
        avg_time = round(sum(move_times) / len(move_times), 1) if move_times else 0.0
        avg_blunder_time = (
            round(sum(blunder_times) / len(blunder_times), 1) if blunder_times else 0.0
        )

        return AggregatedStudentStats(
            student_name=student_name,
            period_description=period_description,
            total_games=total_games,
            wins=wins,
            losses=losses,
            draws=draws,
            win_rate=round((wins / total_games) * 100, 1) if total_games else 0.0,
            white_stats=white_stats,
            black_stats=black_stats,
            avg_accuracy=round(total_accuracy / total_games, 2),
            avg_acpl=int(total_acpl / total_games),
            phase_distribution=PhaseBreakdown(
                opening_blunders=opening_blunders,
                middlegame_blunders=middlegame_blunders,
                endgame_blunders=endgame_blunders,
                total_inaccuracies=total_inaccuracies,
                total_mistakes=total_mistakes,
                total_blunders=total_blunders,
            ),
            time_management=TimeManagementStats(
                total_moves=total_student_moves,
                moves_under_15s_rate=moves_under_15s_rate,
                blunders_in_time_trouble_rate=blunders_in_time_trouble_rate,
                avg_seconds_per_move=avg_time,
                avg_seconds_on_blunders=avg_blunder_time,
            ),
            top_tactical_weaknesses=top_tactical_weaknesses,
            critical_error_samples=critical_error_samples,
        )


# ============================================================================
# ВХОДНЫЕ ДАННЫЕ ДЛЯ ОТЧЁТА ИЗ ПАРТИЙ В БАЗЕ
# ============================================================================

_MONTHS = {
    "ru": ["января", "февраля", "марта", "апреля", "мая", "июня", "июля", "августа", "сентября", "октября", "ноября", "декабря"],
    "en": ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
}


def games_to_aggregator_input(games: List[Any]) -> List[Dict[str, Any]]:
    """Готовит вход для GameMetricsAggregator из проанализированных партий (модель Game).

    Берутся только партии со статусом ``completed``: у остальных нет оценки
    движка, и подставлять за них числа нельзя. Подробный лог ходов
    восстанавливается из ``analysis_json``, чтобы считались фазы, время и темы.
    """
    rows = []
    for g in games:
        if g.analysis_status != "completed" or g.accuracy_score is None:
            continue
        moves = [AnalyzedMove.model_validate(m) for m in (g.analysis_json or [])]
        rows.append({
            "analysis": GameAnalysisResult(
                accuracy_score=float(g.accuracy_score),
                acpl=g.acpl or 0,
                blunders_count=g.blunders_count or 0,
                mistakes_count=g.mistakes_count or 0,
                inaccuracies_count=g.inaccuracies_count or 0,
                time_blunders_count=g.time_spent_blunders_count or 0,
                errors=[m for m in moves if m.severity and m.is_student_move],
                moves_tree=moves,
            ),
            "student_color": g.student_color,
            "result": g.result,
            "opponent_username": g.opponent_username,
        })
    return rows


def describe_period(games: List[Any], language: str = "ru") -> str:
    """Период по датам партий: «25–30 октября 2026» / «October 25–30, 2026»."""
    dates = sorted(g.played_at for g in games if g.played_at)
    if not dates:
        return ""
    first, last = dates[0], dates[-1]
    months = _MONTHS["en" if language == "en" else "ru"]

    if language == "en":
        if (first.year, first.month) == (last.year, last.month):
            days = f"{first.day}" if first.day == last.day else f"{first.day}–{last.day}"
            return f"{months[first.month - 1]} {days}, {last.year}"
        return f"{months[first.month - 1]} {first.day} – {months[last.month - 1]} {last.day}, {last.year}"

    if (first.year, first.month) == (last.year, last.month):
        days = f"{first.day}" if first.day == last.day else f"{first.day}–{last.day}"
        return f"{days} {months[first.month - 1]} {last.year}"
    return f"{first.day} {months[first.month - 1]} – {last.day} {months[last.month - 1]} {last.year}"


def _initials(name: str) -> str:
    """«Diana Akhmetova» -> «D. A.»: во внешний сервис не отправляем полное имя ребёнка."""
    return " ".join(f"{part[0]}." for part in name.split() if part) or "—"


# ============================================================================
# ТЕКСТЫ РЕЗЕРВНЫХ ОТЧЁТОВ (когда ключа OpenAI нет или запрос не удался)
# ============================================================================
# {played}/{won}: формы глагола по полу ученика (только для русского).
_FALLBACK = {
    "ru": {
        "summary": "{name}: {games} за период {period}, побед {wins}, ничьих {draws}, поражений {losses}. "
                   "Средняя точность {acc}%, средняя потеря {acpl} сантипешек за ход.",
        "focus_time": "Главное, над чем стоит работать: решения в цейтноте.",
        "focus_theme": "Главное, над чем стоит работать: тема «{theme}».",
        "focus_phase": "Больше всего грубых ошибок приходится на {phase}.",
        "focus_none": "Повторяющихся проблем по этим партиям не видно.",
        "phase_opening": "дебют", "phase_middlegame": "миттельшпиль", "phase_endgame": "эндшпиль",
        "metrics": "Зевки по стадиям: дебют {o}, миттельшпиль {m}, эндшпиль {e}. Поражения белыми: {lw}, чёрными: {lb}.",
        "p_time_title": "Ошибки в цейтноте (меньше 15 секунд)",
        "p_time_desc": "{pct}% грубых ошибок сделаны, когда на часах оставалось меньше 15 секунд.",
        "p_time_freq": "{pct}% зевков",
        "p_hang_title": "Фигуры остаются без защиты",
        "p_hang_desc": "{n} раз фигура оказалась под боем без защиты.",
        "p_hang_freq": "{pct}% тактических ошибок",
        "p_phase_title": "Ошибки в миттельшпиле",
        "p_phase_desc": "Больше всего зевков ({n}) — в середине партии, когда на доске много фигур и острых вариантов.",
        "p_phase_freq": "{n} зевков",
        "p_none_title": "Стабильная игра",
        "p_none_desc": "Повторяющихся ошибок в этих партиях не найдено.",
        "p_none_freq": "редко",
        "time_bad": "{pct}% зевков сделаны в цейтноте. Стоит потренировать распределение времени: не тратить много на простые ходы.",
        "time_some": "В цейтноте сделано {pct}% зевков. Серьёзной проблемы со временем нет, но следить стоит.",
        "time_none": "Ошибок из-за нехватки времени в этих партиях нет.",
        "lesson_time": "Распределение времени: партии с добавлением 2–3 секунды на ход",
        "lesson_hang": "Перед каждым ходом проверять, все ли фигуры защищены",
        "lesson_mid": "Типовые планы и тактика в миттельшпиле",
        "lesson_tactics": "Решение задач на тактическую зоркость (1–2 хода)",
        "lesson_keep": "Закрепление дебютного репертуара и разбор своих партий",
        "hw_hang_topic": "Защита незащищённых фигур",
        "hw_hang_focus": "Перед ходом спрашивать себя: что атаковал соперник последним ходом?",
        "hw_time_topic": "Игра при нехватке времени",
        "hw_time_focus": "Играть партии с добавлением времени и не опускаться ниже 30 секунд.",
        "hw_tactics_topic": "Тактика в 1–2 хода",
        "hw_tactics_focus": "Решать задачи без спешки, проверяя каждый вариант до конца.",
        "parent_greeting": "Здравствуйте! Делимся новостями о шахматных занятиях: {name}, {period}.",
        "parent_played": "{name} {played} {games}.",
        "parent_won": "{won_verb} {wins} из них.",
        "parent_acc_good": "Ходы были точными: в среднем {acc}% совпадают с лучшими ходами компьютера.",
        "parent_acc_ok": "Точность ходов — {acc}%, и есть куда расти.",
        "parent_effort": "Продолжает регулярно играть и разбирать свои партии.",
        "parent_grow_time": "Учимся не спешить, когда на часах мало времени.",
        "parent_grow_blunders": "Учимся перед каждым ходом проверять, не нападает ли соперник на наши фигуры.",
        "parent_grow_keep": "Продолжаем закреплять то, что уже хорошо получается.",
        # Имя здесь не подставляем: в русском его пришлось бы склонять («Петю»)
        "parent_advice": "Хвалите не только за победы, но и за партии, где получилось долго и внимательно думать над ходами. "
                         "Можно спросить: «Какой ход в этой партии тебе понравился больше всего?»",
        "verbs": {"male": ("сыграл", "Выиграл"), "female": ("сыграла", "Выиграла"), None: ("сыграл(а)", "Выиграл(а)")},
        "games_forms": ("партию", "партии", "партий"),
    },
    "en": {
        "summary": "{name}: {games} in {period}; {wins} wins, {draws} draws, {losses} losses. "
                   "Average accuracy {acc}%, average loss {acpl} centipawns per move.",
        "focus_time": "The main thing to work on is decision-making in time trouble.",
        "focus_theme": "The main thing to work on is the “{theme}” theme.",
        "focus_phase": "Most serious mistakes happen in the {phase}.",
        "focus_none": "These games show no recurring problem.",
        "phase_opening": "opening", "phase_middlegame": "middlegame", "phase_endgame": "endgame",
        "metrics": "Blunders by stage: opening {o}, middlegame {m}, endgame {e}. Losses as White: {lw}, as Black: {lb}.",
        "p_time_title": "Mistakes in time trouble (under 15 seconds)",
        "p_time_desc": "{pct}% of blunders were made with less than 15 seconds on the clock.",
        "p_time_freq": "{pct}% of blunders",
        "p_hang_title": "Pieces left unprotected",
        "p_hang_desc": "{n} times a piece was left under attack without protection.",
        "p_hang_freq": "{pct}% of tactical mistakes",
        "p_phase_title": "Middlegame mistakes",
        "p_phase_desc": "Most blunders ({n}) come in the middle of the game, when there are many pieces and sharp lines.",
        "p_phase_freq": "{n} blunders",
        "p_none_title": "Steady play",
        "p_none_desc": "No recurring mistakes were found in these games.",
        "p_none_freq": "rare",
        "time_bad": "{pct}% of blunders happened in time trouble. Work on time management: don't spend long on simple moves.",
        "time_some": "{pct}% of blunders happened in time trouble. Not a serious problem, but worth keeping an eye on.",
        "time_none": "No mistakes in these games were caused by a lack of time.",
        "lesson_time": "Time management: games with a 2–3 second increment",
        "lesson_hang": "Checking that every piece is protected before each move",
        "lesson_mid": "Typical middlegame plans and tactics",
        "lesson_tactics": "Tactical awareness puzzles (1–2 moves)",
        "lesson_keep": "Strengthening the opening repertoire and reviewing own games",
        "hw_hang_topic": "Protecting undefended pieces",
        "hw_hang_focus": "Before each move ask: what did my opponent's last move attack?",
        "hw_time_topic": "Playing with little time",
        "hw_time_focus": "Play games with an increment and don't let the clock drop below 30 seconds.",
        "hw_tactics_topic": "1–2 move tactics",
        "hw_tactics_focus": "Solve puzzles calmly, checking each line to the end.",
        "parent_greeting": "Hello! Here's an update on {name}'s chess, {period}.",
        "parent_played": "{name} played {games}.",
        "parent_won": "Won {wins} of them.",
        "parent_acc_good": "The moves were accurate: on average {acc}% matched the computer's best moves.",
        "parent_acc_ok": "Move accuracy was {acc}%, with room to grow.",
        "parent_effort": "Keeps playing regularly and reviewing their own games.",
        "parent_grow_time": "Learning not to rush when there is little time on the clock.",
        "parent_grow_blunders": "Learning to check before each move whether the opponent is attacking one of our pieces.",
        "parent_grow_keep": "Keep building on what already works well.",
        "parent_advice": "Praise {name} not only for wins but also for games where they thought long and carefully about their moves. "
                         "You could ask: “Which move in this game did you like best?”",
        "verbs": {"male": ("played", "Won"), "female": ("played", "Won"), None: ("played", "Won")},
        "games_forms": ("game", "games"),
    },
}


def _games_phrase(n: int, language: str) -> str:
    forms = _FALLBACK[language]["games_forms"]
    if language == "en":
        return f"{n} {forms[0] if n == 1 else forms[1]}"
    if n % 10 == 1 and n % 100 != 11:
        return f"{n} {forms[0]}"
    if 2 <= n % 10 <= 4 and not 12 <= n % 100 <= 14:
        return f"{n} {forms[1]}"
    return f"{n} {forms[2]}"


class LLMReporterService:
    """
    Генератор двухуровневых отчетов (CoachReport и ParentReport)
    через Structured Outputs (OpenAI) с резервными шаблонами без ключа.

    ``language`` — "ru" или "en": на этом языке пишутся все тексты отчёта.
    ``gender`` — "male" / "female" / None, для правильных форм глаголов.
    """

    def __init__(self, language: str = "ru", gender: Optional[str] = None):
        self.provider = settings.LLM_PROVIDER
        self.openai_key = settings.OPENAI_API_KEY or os.getenv("OPENAI_API_KEY", "")
        self.model = settings.OPENAI_MODEL
        self.language = "en" if language == "en" else "ru"
        self.gender = gender if gender in ("male", "female") else None
        self._openai_client = None

    def _get_openai_client(self):
        if not self._openai_client and self.openai_key:
            from openai import OpenAI
            self._openai_client = OpenAI(api_key=self.openai_key)
        return self._openai_client

    def _language_rule(self) -> str:
        return ("\nWrite every text field of the answer in English." if self.language == "en"
                else "\nВсе текстовые поля ответа пиши на русском языке.")

    def _restore_name(self, report, stats: AggregatedStudentStats, field: str):
        """Модель видела только инициалы; возвращаем в отчёт настоящее имя."""
        setattr(report, field, stats.student_name)
        return report

    def generate_coach_report(self, stats: AggregatedStudentStats) -> CoachReport:
        """
        Генерация экспертного фактологического отчета для тренера.
        """
        client = self._get_openai_client()
        if not client:
            logger.info("OpenAI API key не настроен. Используем эвристический fallback-генератор CoachReport.")
            return self._fallback_coach_report(stats)

        system_prompt = (
            "Ты — Senior Chess Coach & Data Analyst в профессиональной шахматной академии.\n"
            "Твоя задача — составить строгий фактологический аудит игры ученика на основе агрегированных данных.\n"
            "ПРАВИЛА:\n"
            "1. Тон: экспертный, педагогический, четкий, без воды.\n"
            "2. Выдели ровно топ-3 системных хронических паттерна ошибок ученика на основе фаз и тактических тегов.\n"
            "3. Оцени поведение в цейтноте: как меняется качество решений при < 15 сек на часах.\n"
            "4. Предложи конкретные темы для следующих занятий и сфокусированное домашнее задание."
        ) + self._language_rule()

        user_prompt = f"""
Данные игры ученика:
Имя: {_initials(stats.student_name)}
Период: {stats.period_description}
Всего партий: {stats.total_games} (Побед: {stats.wins}, Поражений: {stats.losses}, Ничьих: {stats.draws}, Винрейт: {stats.win_rate}%)
Баланс цветов: Белыми: {stats.white_stats}, Черными: {stats.black_stats}
Средняя точность (CAPS): {stats.avg_accuracy}% | Средняя потеря сантипешек (ACPL): {stats.avg_acpl}

Распределение ошибок по фазам:
- Дебютные зевки: {stats.phase_distribution.opening_blunders}
- Миттельшпильные зевки: {stats.phase_distribution.middlegame_blunders}
- Эндшпильные зевки: {stats.phase_distribution.endgame_blunders}
- Всего зевков: {stats.phase_distribution.total_blunders}, ошибок: {stats.phase_distribution.total_mistakes}, неточностей: {stats.phase_distribution.total_inaccuracies}

Тайм-менеджмент:
- Доля ходов в цейтноте (< 15с): {stats.time_management.moves_under_15s_rate}%
- Доля зевков под флагом: {stats.time_management.blunders_in_time_trouble_rate}%
- Среднее время на обычный ход: {stats.time_management.avg_seconds_per_move}с, на зевке: {stats.time_management.avg_seconds_on_blunders}с

Топ тактических слабостей:
{json.dumps(stats.top_tactical_weaknesses, ensure_ascii=False, indent=2)}

Примеры критических сбоев:
{json.dumps(stats.critical_error_samples, ensure_ascii=False, indent=2)}
"""

        try:
            completion = client.beta.chat.completions.parse(
                model=self.model,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt},
                ],
                response_format=CoachReport,
                temperature=0.2,
            )
            return self._restore_name(completion.choices[0].message.parsed, stats, "student_name")
        except Exception as exc:
            logger.error(f"Ошибка при вызове OpenAI Structured Output: {exc}. Переход на fallback.")
            return self._fallback_coach_report(stats)

    def generate_parent_report(self, stats: AggregatedStudentStats) -> ParentReport:
        """
        Генерация эмпатичного отчета для родителей без шахматной терминологии.
        """
        client = self._get_openai_client()
        if not client:
            logger.info("OpenAI API key не настроен. Используем эвристический fallback-генератор ParentReport.")
            return self._fallback_parent_report(stats)

        system_prompt = (
            "Ты — заботливый детский шахматный наставник и психолог.\n"
            "Твоя задача — составить отчет для родителей ученика простым, поддерживающим и понятным языком.\n"
            "КРИТИЧЕСКИЕ ПРАВИЛА:\n"
            "1. ЗАПРЕЩЕНО использовать шахматный жаргон: слова 'сантипешки', 'ACPL', 'CAPS', 'миттельшпиль', 'эндшпиль', 'гамбит', 'зевок пешки на c4'.\n"
            "2. Переводить на понятный язык: вместо 'эндшпиль' говорить 'завершающая стадия партии', вместо 'зевок легкой фигуры' говорить 'потеря защитников'.\n"
            "3. Фокус на прогрессе, психологической выдержке, дисциплине и внимательности.\n"
            "4. Зону роста описать доброжелательно, а не как упрек.\n"
            "5. Дать родителю один теплый и применимый совет для дома."
        ) + self._language_rule()

        user_prompt = f"""
Данные ученика:
Имя ребенка: {_initials(stats.student_name)}
Период: {stats.period_description}
Сыграно партий: {stats.total_games} (Побед: {stats.wins})
Точность игры: {stats.avg_accuracy}%
Ошибки: чаще всего в середине игры ({stats.phase_distribution.middlegame_blunders} случаев), в цейтноте ({stats.time_management.blunders_in_time_trouble_rate}% зевков)
Топ уязвимостей: {', '.join([w['tag'] for w in stats.top_tactical_weaknesses])}
"""

        try:
            completion = client.beta.chat.completions.parse(
                model=self.model,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt},
                ],
                response_format=ParentReport,
                temperature=0.3,
            )
            return self._restore_name(completion.choices[0].message.parsed, stats, "child_name")
        except Exception as exc:
            logger.error(f"Ошибка при вызове OpenAI Structured Output: {exc}. Переход на fallback.")
            return self._fallback_parent_report(stats)

    # ========================================================================
    # РЕЗЕРВНЫЕ ОТЧЁТЫ ПО ШАБЛОНАМ: каждое утверждение опирается на данные
    # ========================================================================

    def _t(self, key: str, **params) -> str:
        return _FALLBACK[self.language][key].format(**params)

    def _main_focus(self, stats: AggregatedStudentStats) -> str:
        tm, ph = stats.time_management, stats.phase_distribution
        if tm.blunders_in_time_trouble_rate > 30:
            return self._t("focus_time")
        if stats.top_tactical_weaknesses:
            from app.services.puzzle_service import PuzzleGeneratorService
            title = PuzzleGeneratorService.get_theme_info(stats.top_tactical_weaknesses[0]["tag"])["title"]
            return self._t("focus_theme", theme=title.split(" (")[0])
        by_phase = {"opening": ph.opening_blunders, "middlegame": ph.middlegame_blunders, "endgame": ph.endgame_blunders}
        worst = max(by_phase, key=by_phase.get)
        if by_phase[worst] > 0:
            return self._t("focus_phase", phase=self._t(f"phase_{worst}"))
        return self._t("focus_none")

    def _fallback_coach_report(self, stats: AggregatedStudentStats) -> CoachReport:
        tm, ph = stats.time_management, stats.phase_distribution
        patterns: List[SystemicPattern] = []
        lessons: List[str] = []
        homework: List[HomeworkRecommendation] = []

        if tm.blunders_in_time_trouble_rate > 30:
            pct = tm.blunders_in_time_trouble_rate
            patterns.append(SystemicPattern(
                title=self._t("p_time_title"), description=self._t("p_time_desc", pct=pct),
                frequency=self._t("p_time_freq", pct=pct), severity="critical",
            ))
            lessons.append(self._t("lesson_time"))
            homework.append(HomeworkRecommendation(
                topic=self._t("hw_time_topic"), target_pattern="time_trouble_panic",
                recommended_puzzles_count=5, focus_description=self._t("hw_time_focus"),
            ))

        hanging = next((w for w in stats.top_tactical_weaknesses if w["tag"] == "hanging_piece"), None)
        if hanging:
            patterns.append(SystemicPattern(
                title=self._t("p_hang_title"), description=self._t("p_hang_desc", n=hanging["count"]),
                frequency=self._t("p_hang_freq", pct=hanging["percentage"]),
                severity="critical" if hanging["percentage"] > 25 else "moderate",
            ))
            lessons.append(self._t("lesson_hang"))
            homework.append(HomeworkRecommendation(
                topic=self._t("hw_hang_topic"), target_pattern="hanging_piece",
                recommended_puzzles_count=10, focus_description=self._t("hw_hang_focus"),
            ))

        if ph.middlegame_blunders > 0 and ph.middlegame_blunders >= max(ph.opening_blunders, ph.endgame_blunders):
            patterns.append(SystemicPattern(
                title=self._t("p_phase_title"), description=self._t("p_phase_desc", n=ph.middlegame_blunders),
                frequency=self._t("p_phase_freq", n=ph.middlegame_blunders), severity="moderate",
            ))
            lessons.append(self._t("lesson_mid"))

        if not patterns:
            patterns.append(SystemicPattern(
                title=self._t("p_none_title"), description=self._t("p_none_desc"),
                frequency=self._t("p_none_freq"), severity="minor",
            ))
        if ph.total_blunders or ph.total_mistakes:
            lessons.append(self._t("lesson_tactics"))
        if not lessons:
            lessons.append(self._t("lesson_keep"))
        if not homework:
            homework.append(HomeworkRecommendation(
                topic=self._t("hw_tactics_topic"), target_pattern="tactical_blunder",
                recommended_puzzles_count=5, focus_description=self._t("hw_tactics_focus"),
            ))

        pct = tm.blunders_in_time_trouble_rate
        time_key = "time_bad" if pct > 30 else ("time_some" if pct > 0 else "time_none")

        return CoachReport(
            student_name=stats.student_name,
            period=stats.period_description,
            executive_summary=self._t(
                "summary", name=stats.student_name, games=_games_phrase(stats.total_games, self.language),
                period=stats.period_description, wins=stats.wins, draws=stats.draws, losses=stats.losses,
                acc=round(stats.avg_accuracy, 1), acpl=stats.avg_acpl,
            ) + " " + self._main_focus(stats),
            aggregated_metrics_summary=self._t(
                "metrics", o=ph.opening_blunders, m=ph.middlegame_blunders, e=ph.endgame_blunders,
                lw=stats.white_stats.get("losses", 0), lb=stats.black_stats.get("losses", 0),
            ),
            systemic_patterns=patterns[:3],
            time_trouble_verdict=self._t(time_key, pct=pct),
            next_lessons_plan=lessons[:3],
            homework_assignment=homework,
        )

    def _fallback_parent_report(self, stats: AggregatedStudentStats) -> ParentReport:
        played_verb, won_verb = _FALLBACK[self.language]["verbs"][self.gender]
        name = stats.student_name.split()[0] if stats.student_name else stats.student_name
        tm, ph = stats.time_management, stats.phase_distribution

        achievements = [self._t("parent_played", name=name, played=played_verb,
                                games=_games_phrase(stats.total_games, self.language))]
        if stats.wins:
            achievements[0] += " " + self._t("parent_won", won_verb=won_verb, wins=stats.wins)
        acc = int(round(stats.avg_accuracy))
        achievements.append(self._t("parent_acc_good" if acc >= 75 else "parent_acc_ok", acc=acc))
        achievements.append(self._t("parent_effort"))

        growth = []
        if tm.blunders_in_time_trouble_rate > 30:
            growth.append(self._t("parent_grow_time"))
        if ph.total_blunders:
            growth.append(self._t("parent_grow_blunders"))
        if not growth:
            growth.append(self._t("parent_grow_keep"))

        return ParentReport(
            child_name=stats.student_name,
            period=stats.period_description,
            greeting_and_summary=self._t("parent_greeting", name=name, period=stats.period_description),
            achievements=achievements,
            areas_for_growth=growth,
            home_support_advice=self._t("parent_advice", name=name),
        )
