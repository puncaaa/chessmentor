"""Тесты переводов: у каждого ключа есть оба языка и одинаковые плейсхолдеры."""
import string

from app.ui import i18n


def _placeholders(text):
    return {name for _, name, _, _ in string.Formatter().parse(text) if name}


def test_every_key_has_both_languages_with_same_placeholders():
    for key, (ru, en) in i18n.TEXTS.items():
        assert ru.strip() and en.strip(), key
        assert _placeholders(ru) == _placeholders(en), key


def test_t_formats_and_falls_back_to_key():
    assert i18n.t("games.key_moments", lang="en", n=3) == "Key moments: 3"
    assert i18n.t("games.key_moments", lang="ru", n=3) == "Ключевые моменты: 3"
    assert i18n.t("no.such.key") == "no.such.key"


def test_russian_plurals():
    assert [i18n.plural("games", n, lang="ru") for n in (1, 2, 5, 11, 21, 22)] == [
        "1 партия", "2 партии", "5 партий", "11 партий", "21 партия", "22 партии",
    ]
    assert i18n.plural("games", 1, lang="en") == "1 game"
    assert i18n.plural("years", 12, lang="en") == "12 years old"


def test_every_puzzle_theme_from_service_is_translated():
    from app.services.puzzle_service import LICHESS_THEME_MAPPING
    for info in LICHESS_THEME_MAPPING.values():
        assert info["theme"] in i18n.PUZZLE_THEMES
