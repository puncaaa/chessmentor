"""Тесты резервных отчётов: только факты из данных, нужный язык и род."""
import re
from datetime import datetime
from types import SimpleNamespace

from app.schemas.reports import AggregatedStudentStats, PhaseBreakdown, TimeManagementStats
from app.services.llm_reporter import LLMReporterService, describe_period

CYRILLIC = re.compile("[А-Яа-яЁё]")


def _stats(wins=0, losses=3, blunders=0, time_rate=0.0, weaknesses=None):
    return AggregatedStudentStats(
        student_name="Diana Akhmetova", period_description="Oct 25–30, 2026",
        total_games=wins + losses, wins=wins, losses=losses, draws=0, win_rate=0.0,
        avg_accuracy=70.0, avg_acpl=40,
        phase_distribution=PhaseBreakdown(middlegame_blunders=blunders, total_blunders=blunders),
        time_management=TimeManagementStats(blunders_in_time_trouble_rate=time_rate),
        top_tactical_weaknesses=weaknesses or [],
    )


def _all_text(report):
    return " ".join(str(v) for v in report.model_dump().values())


def test_english_reports_contain_no_russian():
    reporter = LLMReporterService(language="en", gender="female")
    reporter.openai_key = ""  # всегда шаблонный отчёт
    stats = _stats(blunders=2, time_rate=50.0, weaknesses=[{"tag": "hanging_piece", "count": 2, "percentage": 100.0}])
    for report in (reporter.generate_coach_report(stats), reporter.generate_parent_report(stats)):
        assert not CYRILLIC.search(_all_text(report)), _all_text(report)


def test_no_invented_claims_without_data():
    reporter = LLMReporterService(language="ru", gender="female")
    reporter.openai_key = ""
    parent = reporter.generate_parent_report(_stats(wins=0))
    achievements = " ".join(parent.achievements)
    assert "Выиграла" not in achievements  # побед не было, хвалить за них нечего
    assert "сыграла" in achievements  # глагол в женском роде
    coach = reporter.generate_coach_report(_stats())
    assert "цейтнот" not in coach.executive_summary.lower()  # данных о цейтноте нет


def test_period_from_game_dates():
    games = [SimpleNamespace(played_at=datetime(2026, 10, 25)), SimpleNamespace(played_at=datetime(2026, 10, 30))]
    assert describe_period(games, "ru") == "25–30 октября 2026"
    assert describe_period(games, "en") == "October 25–30, 2026"
