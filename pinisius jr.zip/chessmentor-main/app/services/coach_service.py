"""Тренеры и их ученики: вход в систему, добавление и редактирование учеников.

Сервис не зависит от Streamlit: принимает обычные значения, возвращает
простые dataclass-объекты, а ошибки ввода сообщает через ``ValidationError``
с понятным текстом на русском, который можно сразу показать пользователю.
"""
import hashlib
import hmac
import re
import secrets
from dataclasses import dataclass, field
from typing import Dict, List, Optional

from sqlalchemy import func, select, update
from sqlalchemy.orm import Session

from app.db.session import get_db_session
from app.models.chess import Coach, Game, StudentChessAccount, StudentProfile

GENDERS = {"male": "Мужской", "female": "Женский"}
PLATFORMS = {"lichess": "Lichess", "chesscom": "Chess.com"}
MIN_AGE, MAX_AGE = 4, 99
MIN_PASSWORD_LENGTH = 6

_PBKDF2_ITERATIONS = 200_000

# Допустимые ники и ссылки на профили (можно вставить ник или ссылку целиком)
_USERNAME_RULES = {
    "lichess": (re.compile(r"^[A-Za-z0-9][A-Za-z0-9_-]{1,29}$"),
                re.compile(r"lichess\.org/@/([A-Za-z0-9_-]+)", re.IGNORECASE)),
    "chesscom": (re.compile(r"^[A-Za-z0-9][A-Za-z0-9_-]{2,24}$"),
                 re.compile(r"chess\.com/(?:member|players?)/([A-Za-z0-9_-]+)", re.IGNORECASE)),
}


class ValidationError(ValueError):
    """Ошибка во введённых данных; текст предназначен для пользователя."""


@dataclass
class CoachView:
    id: str
    full_name: str


@dataclass
class StudentView:
    id: str
    first_name: str
    last_name: str
    gender: Optional[str]
    age: Optional[int]
    accounts: Dict[str, str] = field(default_factory=dict)  # platform -> username
    games_count: int = 0

    @property
    def full_name(self) -> str:
        return f"{self.first_name} {self.last_name}".strip()


# ---------------------------------------------------------------------------
# Пароли
# ---------------------------------------------------------------------------
def hash_password(password: str) -> str:
    """PBKDF2-SHA256 со случайной солью; результат вида 'salt$hash'."""
    salt = secrets.token_hex(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), bytes.fromhex(salt), _PBKDF2_ITERATIONS)
    return f"{salt}${digest.hex()}"


def verify_password(password: str, stored: str) -> bool:
    try:
        salt, expected = stored.split("$", 1)
    except ValueError:
        return False
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), bytes.fromhex(salt), _PBKDF2_ITERATIONS)
    return hmac.compare_digest(digest.hex(), expected)


# ---------------------------------------------------------------------------
# Проверка ввода
# ---------------------------------------------------------------------------
def normalize_username(platform: str, raw: Optional[str]) -> Optional[str]:
    """Ник из поля ввода: пусто → None, ссылка на профиль → ник из ссылки."""
    value = (raw or "").strip().rstrip("/")
    if not value:
        return None
    pattern, url_pattern = _USERNAME_RULES[platform]
    match = url_pattern.search(value)
    if match:
        value = match.group(1)
    value = value.lstrip("@")
    if not pattern.match(value):
        raise ValidationError(f"Ник {PLATFORMS[platform]} «{raw}» выглядит неправильно. Нужен ник или ссылка на профиль.")
    return value


def split_full_name(full_name: str) -> tuple:
    parts = (full_name or "").split()
    if not parts:
        raise ValidationError("Введите имя ученика.")
    return parts[0], " ".join(parts[1:])


def _validate_student(full_name: str, gender: Optional[str], age: Optional[int]) -> tuple:
    first, last = split_full_name(full_name)
    if gender is not None and gender not in GENDERS:
        raise ValidationError("Выберите пол из списка.")
    if age is not None and not (MIN_AGE <= int(age) <= MAX_AGE):
        raise ValidationError(f"Возраст должен быть от {MIN_AGE} до {MAX_AGE} лет.")
    return first, last


def _check_account_free(session: Session, platform: str, username: str, student_id: Optional[str]) -> None:
    """Один аккаунт платформы может принадлежать только одному ученику."""
    owner = session.execute(
        select(StudentChessAccount)
        .where(StudentChessAccount.platform == platform,
               func.lower(StudentChessAccount.username) == username.lower())
    ).scalars().first()
    if owner and owner.student_profile_id != student_id:
        raise ValidationError(f"Аккаунт {PLATFORMS[platform]} «{username}» уже привязан к другому ученику.")


# ---------------------------------------------------------------------------
# Тренеры
# ---------------------------------------------------------------------------
def list_coaches() -> List[CoachView]:
    with get_db_session() as session:
        coaches = session.execute(select(Coach).order_by(Coach.full_name)).scalars().all()
        return [CoachView(c.id, c.full_name) for c in coaches]


def create_coach(full_name: str, password: str) -> CoachView:
    name = " ".join((full_name or "").split())
    if not name:
        raise ValidationError("Введите имя тренера.")
    if len(password or "") < MIN_PASSWORD_LENGTH:
        raise ValidationError(f"Пароль должен быть не короче {MIN_PASSWORD_LENGTH} символов.")
    with get_db_session() as session:
        exists = session.execute(select(Coach).where(func.lower(Coach.full_name) == name.lower())).scalars().first()
        if exists:
            raise ValidationError(f"Тренер «{name}» уже зарегистрирован.")
        coach = Coach(full_name=name, password_hash=hash_password(password))
        session.add(coach)
        session.flush()
        return CoachView(coach.id, coach.full_name)


def authenticate(coach_id: str, password: str) -> Optional[CoachView]:
    """Возвращает тренера при верном пароле, иначе None."""
    with get_db_session() as session:
        coach = session.get(Coach, coach_id)
        if coach and verify_password(password or "", coach.password_hash):
            return CoachView(coach.id, coach.full_name)
    return None


# ---------------------------------------------------------------------------
# Ученики
# ---------------------------------------------------------------------------
def list_students(coach_id: str) -> List[StudentView]:
    """Ученики тренера по алфавиту, с аккаунтами и числом партий в базе."""
    with get_db_session() as session:
        students = session.execute(
            select(StudentProfile)
            .where(StudentProfile.coach_id == coach_id)
            .order_by(StudentProfile.first_name, StudentProfile.last_name)
        ).scalars().all()
        counts = dict(session.execute(
            select(Game.student_profile_id, func.count(Game.id))
            .where(Game.student_profile_id.in_([s.id for s in students]))
            .group_by(Game.student_profile_id)
        ).all())
        return [
            StudentView(
                id=s.id, first_name=s.first_name, last_name=s.last_name, gender=s.gender, age=s.age,
                accounts={a.platform: a.username for a in s.chess_accounts if a.is_active},
                games_count=counts.get(s.id, 0),
            )
            for s in students
        ]


def save_student(
    coach_id: str,
    full_name: str,
    gender: Optional[str],
    age: Optional[int],
    lichess: Optional[str] = None,
    chesscom: Optional[str] = None,
    student_id: Optional[str] = None,
) -> str:
    """Создаёт ученика (``student_id=None``) или обновляет существующего.

    Ники можно передавать как есть или ссылкой на профиль. Пустой ник
    отвязывает аккаунт этой платформы. Возвращает id ученика.
    """
    first, last = _validate_student(full_name, gender, age)
    usernames = {
        "lichess": normalize_username("lichess", lichess),
        "chesscom": normalize_username("chesscom", chesscom),
    }

    with get_db_session() as session:
        if student_id:
            student = session.get(StudentProfile, student_id)
            if not student or student.coach_id != coach_id:
                raise ValidationError("Ученик не найден среди ваших учеников.")
        else:
            student = StudentProfile(coach_id=coach_id, first_name=first, last_name=last)
            session.add(student)
            session.flush()

        student.first_name, student.last_name = first, last
        student.gender = gender
        student.age = int(age) if age is not None else None

        current = {a.platform: a for a in student.chess_accounts}
        for platform, username in usernames.items():
            account = current.get(platform)
            if username is None:
                if account:
                    # Партии ученика остаются, просто теряют ссылку на удалённый аккаунт
                    session.execute(
                        update(Game).where(Game.chess_account_id == account.id).values(chess_account_id=None)
                    )
                    session.delete(account)
                continue
            _check_account_free(session, platform, username, student.id)
            if account:
                if account.username.lower() != username.lower():
                    # Новый ник — значит, синхронизацию начинаем заново
                    account.last_game_played_at = None
                account.username = username
                account.is_active = True
            else:
                session.add(StudentChessAccount(student_profile_id=student.id, platform=platform, username=username))
        session.flush()
        return student.id


def delete_student(coach_id: str, student_id: str) -> None:
    """Удаляет ученика тренера вместе с его партиями и разбором ошибок."""
    with get_db_session() as session:
        student = session.get(StudentProfile, student_id)
        if not student or student.coach_id != coach_id:
            raise ValidationError("Ученик не найден среди ваших учеников.")
        session.delete(student)
