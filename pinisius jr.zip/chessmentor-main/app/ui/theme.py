"""Визуальная тема дашборда: палитра, подключение CSS и небольшие HTML-хелперы.

Вся стилизация живёт в ``styles/theme.css``; здесь только то, что нужно
из Python (цвета для Plotly и разметка повторяющихся элементов).
"""
import base64
import html
import re
from pathlib import Path
from typing import Optional

import streamlit as st

_CSS_PATH = Path(__file__).parent / "styles" / "theme.css"
_HERO_PATH = Path(__file__).parent / "assets" / "hero.jpg"

# Палитра продублирована из theme.css для графиков Plotly.
PALETTE = {
    "paper": "#F4F5EF",
    "sheet": "#FCFCF9",
    "buff": "#E8EBCB",
    "felt": "#4E6E39",
    "felt_deep": "#364F27",
    "ink": "#1E2420",
    "pencil": "#676E66",
    "rule": "#D7DBCD",
    "flag": "#B42318",
    "amber": "#9A5B0B",
    "dubious": "#2F6690",
}
SANS = "Golos Text, -apple-system, Segoe UI, sans-serif"
SERIF = "Literata, Georgia, serif"

# Шахматные знаки аннотации вместо слов BLUNDER / MISTAKE / INACCURACY.
SEVERITY_MARKS = {
    "blunder": ("??", "Зевок"),
    "mistake": ("?", "Ошибка"),
    "inaccuracy": ("?!", "Неточность"),
}

PHASE_NAMES = {"opening": "Дебют", "middlegame": "Миттельшпиль", "endgame": "Эндшпиль"}

# Эмодзи, которые сервисы вставляют в текст отчётов (⚠️, 🔍 и т.п.).
_EMOJI = re.compile("[\U0001F300-\U0001FAFF\u2600-\u26FF\u2700-\u27BF\uFE0F]")

_FIGURINES = {"K": "♔", "Q": "♕", "R": "♖", "B": "♗", "N": "♘"}


def inject_theme() -> None:
    """Подключает CSS темы и фото для шапки страницы."""
    css = _CSS_PATH.read_text(encoding="utf-8")
    if _HERO_PATH.exists():
        # Фото встраивается как data URI: Streamlit не раздаёт локальные файлы без отдельной настройки.
        hero_b64 = base64.b64encode(_HERO_PATH.read_bytes()).decode("ascii")
        css += f"\n:root {{ --hero-image: url('data:image/jpeg;base64,{hero_b64}'); }}"
    st.html(f"<style>{css}</style>")


def render_svg_html(markup: str) -> None:
    """Рендерит HTML с встроенным SVG.

    ``st.html`` вырезает теги ``<svg>``, а ``st.markdown`` их сохраняет. Чтобы
    Markdown не принял отступы за блок кода, разметка сжимается в одну строку.
    """
    compact = " ".join(line.strip() for line in markup.splitlines() if line.strip())
    st.markdown(compact, unsafe_allow_html=True)


def figurine(san: Optional[str]) -> str:
    """Переводит SAN в фигурную нотацию: ``Nf3`` → ``♘f3`` (как в шахматных книгах)."""
    if not san:
        return ""
    return "".join(_FIGURINES.get(ch, ch) for ch in san)


def severity_mark(severity: str, count: Optional[int] = None, with_label: bool = True) -> str:
    """HTML-метка ошибки: ``??``, ``?`` или ``?!`` с подписью и, если передано, количеством."""
    glyph, label = SEVERITY_MARKS.get(severity, ("?", severity))
    if with_label:
        caption = f"<span>{label if count is None else f'{label}: {count}'}</span>"
    else:
        # Компактный вид: только знак и число, подпись — во всплывающей подсказке
        caption = f"<span>{count}</span>" if count is not None else ""
        return f'<span class="mark mark-{severity}" title="{label}">{glyph}{caption}</span>'

    return f'<span class="mark mark-{severity}">{glyph}{caption}</span>'


def rich_text(text: Optional[str]) -> str:
    """Экранирует текст для HTML и превращает ``**жирный**`` из отчётов в ``<b>``."""
    safe = html.escape(_EMOJI.sub("", text or "").strip())
    return re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", safe).replace("\n", "<br>")


def short_theme_title(title: str) -> str:
    """Убирает английское пояснение в скобках: ``Вилки (Forks)`` → ``Вилки``."""
    return title.split(" (")[0].strip()


def phase_name(phase: Optional[str]) -> str:
    return PHASE_NAMES.get(phase or "", phase or "—")


def plotly_layout(**overrides) -> dict:
    """Базовый layout для графиков Plotly в цветах темы."""
    axis = dict(
        gridcolor=PALETTE["rule"],
        linecolor=PALETTE["rule"],
        zeroline=False,
        tickfont=dict(color=PALETTE["pencil"], size=12, family=SANS),
    )
    layout = dict(
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        font=dict(family=SANS, color=PALETTE["ink"]),
        margin=dict(l=10, r=24, t=16, b=10),
        height=280,
        xaxis=dict(axis),
        yaxis=dict(axis),
        hoverlabel=dict(bgcolor=PALETTE["sheet"], bordercolor=PALETTE["rule"], font=dict(family=SANS, color=PALETTE["ink"])),
    )
    layout.update(overrides)
    return layout
