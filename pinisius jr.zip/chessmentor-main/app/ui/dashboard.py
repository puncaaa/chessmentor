import html
import os
import sys
import io
import base64
import time
from typing import List, Dict, Any, Optional

import streamlit as st
import chess
import chess.svg
import chess.pgn
import plotly.graph_objects as go
from sqlalchemy import select

# Добавляем корневую директорию проекта в sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../..")))

# Настройка Celery на eager-режим для работы внутри веб-приложения
from app.tasks.celery_app import celery_app
celery_app.conf.update(
    task_always_eager=True,
    task_eager_propagates=True,
    broker_url="memory://",
    result_backend="cache+memory://",
)

from app.db.session import init_db, get_db_session
from app.models.chess import Game, ChessErrorEvent
from app.services import coach_service
from app.tasks.sync_tasks import sync_student_games
from app.services.chess_analyzer import ChessEngineAnalyzer
from app.services.llm_reporter import GameMetricsAggregator, LLMReporterService
from app.services.puzzle_service import PuzzleGeneratorService
from app.services.pdf_generator import PDFReportGenerator
from app.services.opening_analyzer import OpeningAnalyzerService
from app.services.worksheet_generator import WorksheetPDFGenerator
from app.ui.components.chessboard_component import render_interactive_chessboard
from app.ui.charts import accuracy_timeline, rating_summary, ring, short_date
from app.ui.theme import (
    PALETTE, SANS, SEVERITY_MARKS,
    inject_theme, render_svg_html, figurine, severity_mark, phase_name, plotly_layout, rich_text, short_theme_title,
)
from app.schemas.chess import GameAnalysisResult

# ============================================================================
# КОНФИГУРАЦИЯ СТРАНИЦЫ И ТЕМА
# ============================================================================
st.set_page_config(
    page_title="ChessMentor",
    page_icon="♞",
    layout="wide",
    initial_sidebar_state="expanded"
)


def render_html(html_str: str):
    """Нативный рендеринг HTML в Streamlit без искажения Markdown-парсером."""
    st.html(html_str)


inject_theme()
init_db()

# ============================================================================
# ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ
# ============================================================================
@st.cache_data
def render_chessboard_svg(
    fen: str,
    played_uci: Optional[str] = None,
    best_uci: Optional[str] = None,
    student_color: str = "white",
    size: int = 420
) -> str:
    """Генерация SVG доски со стрелками ошибки (красная) и лучшего хода (зелёная)."""
    board = chess.Board(fen)
    arrows = []
    for uci, color in ((played_uci, "#B42318cc"), (best_uci, "#4E6E39cc")):
        if uci and len(uci) >= 4:
            try:
                arrows.append(chess.svg.Arrow(chess.parse_square(uci[:2]), chess.parse_square(uci[2:4]), color=color))
            except ValueError:
                pass

    orientation = chess.WHITE if student_color == "white" else chess.BLACK
    svg = chess.svg.board(
        board=board, arrows=arrows, orientation=orientation, size=size,
        colors={"square light": "#E8EBCB", "square dark": "#7C9A5E"},
    )
    b64 = base64.b64encode(svg.encode("utf-8")).decode("utf-8")
    return f'<div style="display:flex;justify-content:center;margin:12px 0;"><img src="data:image/svg+xml;base64,{b64}" width="{size}" height="{size}"/></div>'


def parse_game_plies(pgn_str: str, error_events: List[ChessErrorEvent]) -> List[Dict[str, Any]]:
    """Парсинг всех полуходов партии с FEN и подписью для навигации по доске."""
    if not pgn_str:
        return []
    try:
        game = chess.pgn.read_game(io.StringIO(pgn_str))
        if not game:
            return []

        errors_by_uci = {e.played_move_uci: e for e in error_events if e.played_move_uci}
        board = game.board()

        plies = [{
            "ply": 0,
            "san": "Начальная позиция",
            "uci": "",
            "fen": board.fen(),
            "move_number": 0,
            "is_white": True,
            "eval_text": "Ход белых",
            "is_error": False,
            "error_severity": None,
            "error_cpl": 0,
            "error": None
        }]

        ply_idx = 1
        for node in game.mainline():
            move = node.move
            san = figurine(node.san())
            uci = move.uci()
            is_white = board.turn == chess.WHITE
            move_num = board.fullmove_number
            board.push(move)

            err = errors_by_uci.get(uci)
            if err:
                glyph, label = SEVERITY_MARKS.get(err.severity, ("?", err.severity))
                theme_title = short_theme_title(PuzzleGeneratorService.get_theme_info(err.tactical_tag or "tactical_blunder")["title"])
                eval_text = f"{glyph} {label}: −{err.centipawn_loss} сантипешек. {theme_title}"
            elif ply_idx <= 14:
                eval_text = "Дебют"
            elif ply_idx <= 40:
                eval_text = "Миттельшпиль"
            else:
                eval_text = "Эндшпиль"

            plies.append({
                "ply": ply_idx,
                "san": f"{move_num}. {san}" if is_white else f"{move_num}… {san}",
                "uci": uci,
                "fen": board.fen(),
                "move_number": move_num,
                "is_white": is_white,
                "eval_text": eval_text,
                "notation": san,
                "glyph": SEVERITY_MARKS.get(err.severity, ("?",))[0] if err else "",
                "is_error": bool(err),
                "error_severity": err.severity if err else None,
                "error_cpl": err.centipawn_loss if err else 0,
                "error": None
            })
            ply_idx += 1

        return plies
    except Exception:
        return []


def game_outcome(game: Game) -> str:
    """Исход партии с точки зрения ученика: 'win', 'loss' или 'draw'."""
    res = game.result or "*"
    if (game.student_color == "white" and res == "1-0") or (game.student_color == "black" and res == "0-1"):
        return "win"
    if (game.student_color == "white" and res == "0-1") or (game.student_color == "black" and res == "1-0"):
        return "loss"
    return "draw"


OUTCOME_CHIPS = {
    "win": ("chip-win", "Победа"),
    "loss": ("chip-loss", "Поражение"),
    "draw": ("chip-draw", "Ничья"),
}
PLATFORM_NAMES = coach_service.PLATFORMS


def outcome_chip(game: Game) -> str:
    css, label = OUTCOME_CHIPS[game_outcome(game)]
    result = (game.result or "*").replace("1/2", "½").replace("-", "–")
    return f'<span class="chip {css}">{label}, {result}</span>'


def note_box(kind: str, title: str, body: str = "") -> str:
    """Блок обратной связи: kind = 'good' | 'bad' | 'info'."""
    body_html = f"<div>{body}</div>" if body else ""
    return f'<div class="note-box note-{kind}"><div class="title">{title}</div>{body_html}</div>'


def age_label(age: Optional[int]) -> str:
    """«11 лет», «2 года», «21 год» — с правильным окончанием."""
    if age is None:
        return ""
    if age % 10 == 1 and age % 100 != 11:
        word = "год"
    elif 2 <= age % 10 <= 4 and not 12 <= age % 100 <= 14:
        word = "года"
    else:
        word = "лет"
    return f"{age} {word}"


def accounts_label(accounts: Dict[str, str]) -> str:
    if not accounts:
        return "аккаунты не привязаны"
    return ", ".join(f"{PLATFORM_NAMES[p]}: {html.escape(u)}" for p, u in accounts.items())


def flash(kind: str, text: str) -> None:
    """Сообщение, которое переживёт st.rerun() и покажется один раз."""
    st.session_state["flash"] = (kind, text)


def show_flash() -> None:
    message = st.session_state.pop("flash", None)
    if message:
        kind, text = message
        (st.success if kind == "success" else st.info)(text)


def reset_student_state() -> None:
    for key in ("student_id", "student_name", "cached_coach_report", "cached_parent_report"):
        st.session_state.pop(key, None)


# ============================================================================
# БОКОВАЯ ПАНЕЛЬ: ВХОД ТРЕНЕРА И ВЫБОР УЧЕНИКА
# ============================================================================
coach: Optional[coach_service.CoachView] = st.session_state.get("coach")
students: List[coach_service.StudentView] = []
current_student: Optional[coach_service.StudentView] = None
sync_btn = False
games_count = 3

with st.sidebar:
    render_html("""
    <div class="brand">
        <div class="brand-mark"><span></span><span></span><span></span><span></span></div>
        <div>
            <div class="brand-name">ChessMentor</div>
            <div class="brand-sub">Кабинет тренера</div>
        </div>
    </div>
    """)
    st.divider()

    if not coach:
        coaches = coach_service.list_coaches()
        if coaches:
            st.subheader("Вход")
            with st.form("login"):
                picked = st.selectbox("Тренер", options=coaches, format_func=lambda c: c.full_name)
                password = st.text_input("Пароль", type="password")
                if st.form_submit_button("Войти", type="primary", use_container_width=True):
                    logged_in = coach_service.authenticate(picked.id, password)
                    if logged_in:
                        st.session_state["coach"] = logged_in
                        reset_student_state()
                        st.rerun()
                    st.error("Неверный пароль. Попробуйте ещё раз.")

        with st.expander("Я новый тренер", expanded=not coaches):
            with st.form("register", clear_on_submit=False):
                new_name = st.text_input("Имя и фамилия")
                new_password = st.text_input("Пароль", type="password", help=f"Не короче {coach_service.MIN_PASSWORD_LENGTH} символов")
                new_password2 = st.text_input("Пароль ещё раз", type="password")
                if st.form_submit_button("Создать аккаунт", use_container_width=True):
                    if new_password != new_password2:
                        st.error("Пароли не совпадают.")
                    else:
                        try:
                            st.session_state["coach"] = coach_service.create_coach(new_name, new_password)
                            reset_student_state()
                            flash("success", "Аккаунт создан. Добавьте первого ученика.")
                            st.rerun()
                        except coach_service.ValidationError as exc:
                            st.error(str(exc))
    else:
        coach_col, logout_col = st.columns([3, 2], vertical_alignment="center")
        with coach_col:
            render_html(f'<div class="coach-name">{html.escape(coach.full_name)}</div><div class="lbl">тренер</div>')
        with logout_col:
            if st.button("Выйти", use_container_width=True):
                st.session_state.pop("coach", None)
                reset_student_state()
                st.rerun()

        students = coach_service.list_students(coach.id)
        st.subheader(f"Ученики: {len(students)}")
        if not students:
            st.caption("Пока никого нет. Добавьте ученика во вкладке «Ученики».")
        else:
            ids = [s.id for s in students]
            if st.session_state.get("student_id") not in ids:
                st.session_state["student_id"] = ids[0]
            by_id = {s.id: s for s in students}
            chosen_id = st.radio(
                "Ученик",
                options=ids,
                index=ids.index(st.session_state["student_id"]),
                format_func=lambda sid: f"{by_id[sid].full_name}" + (f", {age_label(by_id[sid].age)}" if by_id[sid].age else ""),
                label_visibility="collapsed",
            )
            if chosen_id != st.session_state["student_id"]:
                st.session_state.pop("cached_coach_report", None)
                st.session_state.pop("cached_parent_report", None)
            st.session_state["student_id"] = chosen_id
            current_student = by_id[chosen_id]
            st.session_state["student_name"] = current_student.full_name

            st.divider()
            games_count = st.slider("Сколько последних партий загрузить", min_value=3, max_value=10, value=3)
            sync_btn = st.button(
                "Загрузить и разобрать партии",
                use_container_width=True,
                type="primary",
                disabled=not current_student.accounts,
            )
            if current_student.accounts:
                st.caption("Партии скачиваются с платформ и проверяются движком Stockfish. Обычно это занимает до минуты.")
            else:
                st.caption("У ученика нет привязанных аккаунтов. Добавьте ник Lichess или Chess.com во вкладке «Ученики».")

if not coach:
    render_html("""
    <div class="page-head">
        <h1>Кабинет тренера</h1>
        <div class="meta">Войдите слева, чтобы увидеть своих учеников и их партии.</div>
    </div>
    """)
    st.stop()

# Обработка синхронизации
if sync_btn and current_student:
    with st.spinner(f"Загружаем партии {current_student.full_name} и проверяем их движком…"):
        st.session_state.pop("cached_coach_report", None)
        st.session_state.pop("cached_parent_report", None)
        t0 = time.perf_counter()
        res = sync_student_games(student_id=current_student.id, max_games=games_count)
        elapsed = time.perf_counter() - t0
        flash("success", f"Готово за {elapsed:.1f} с. Новых партий: {res.get('new_games', 0)}, уже были в базе: {res.get('skipped_duplicates', 0)}.")
        st.rerun()

current_student_id = current_student.id if current_student else None

# Загрузка партий ученика и ошибок
games_list: List[Game] = []
error_events_by_game: Dict[str, List[ChessErrorEvent]] = {}
all_student_errors: List[ChessErrorEvent] = []

if current_student_id:
    with get_db_session() as session:
        games_list = list(session.execute(
            select(Game)
            .where(Game.student_profile_id == current_student_id)
            .order_by(Game.played_at.desc())
        ).scalars().all())

        if games_list:
            all_student_errors = list(session.execute(
                select(ChessErrorEvent)
                .where(ChessErrorEvent.student_profile_id == current_student_id)
                .order_by(ChessErrorEvent.move_number.asc())
            ).scalars().all())
            for err in all_student_errors:
                error_events_by_game.setdefault(err.game_id, []).append(err)

# ============================================================================
# ШАПКА И ВКЛАДКИ
# ============================================================================
if current_student:
    student_display_name = current_student.full_name
    details = [d for d in (age_label(current_student.age), accounts_label(current_student.accounts)) if d]
    render_html(f"""
    <div class="page-head">
        {rating_summary(games_list)}
        <h1>{html.escape(student_display_name)}</h1>
        <div class="meta">{'; '.join(details)}. Партий в базе: <b>{len(games_list)}</b></div>
    </div>
    """)
else:
    student_display_name = "Ученик"
    render_html(f"""
    <div class="page-head">
        <h1>{html.escape(coach.full_name)}</h1>
        <div class="meta">Добавьте учеников во вкладке «Ученики», и здесь появятся их партии и прогресс.</div>
    </div>
    """)

show_flash()

tab_board, tab_analytics, tab_ai, tab_students = st.tabs(["Партии", "Прогресс", "Отчёты", "Ученики"])

# ----------------------------------------------------------------------------
# ВКЛАДКА 1: СПИСОК ПАРТИЙ И ДОСКА
# ----------------------------------------------------------------------------
BOARD_MODE_TRAINER = "Найти лучший ход"
BOARD_MODE_REPLAY = "Просмотр партии"

with tab_board:
    if not games_list:
        render_html(note_box(
            "info",
            "Партий пока нет",
            "Выберите ученика в панели слева и нажмите «Загрузить и разобрать партии».",
        ))
    else:
        # ---------- Выбор партии и короткая сводка по ней ----------
        col_pick, col_mode = st.columns([5, 7], gap="large", vertical_alignment="bottom")
        with col_pick:
            game_options = {
                f"{short_date(g)}: {g.opponent_username}, {(g.result or '*').replace('1/2', '½')}": g.id
                for g in games_list
            }
            selected_label = st.selectbox("Партия", options=list(game_options.keys()))
            selected_game_id = game_options[selected_label]
            selected_game = next(g for g in games_list if g.id == selected_game_id)
        with col_mode:
            board_mode = st.radio(
                "Режим доски",
                options=[BOARD_MODE_TRAINER, BOARD_MODE_REPLAY],
                horizontal=True,
                label_visibility="collapsed"
            )

        color_label = "белыми" if selected_game.student_color == "white" else "чёрными"
        acc_val = float(selected_game.accuracy_score or 0.0)
        render_html(f"""
        <div class="game-strip">
            <div>
                <div class="panel-row">
                    <span class="lbl">Играл {color_label}, {selected_game.time_control or 'контроль не указан'}</span>
                    {outcome_chip(selected_game)}
                </div>
                <div class="opponent">
                    {selected_game.opponent_username}
                    <span class="rating">{selected_game.opponent_rating or 'без рейтинга'}</span>
                </div>
            </div>
            <div>
                <span class="lbl">Точность</span>
                <span class="fig">{acc_val:g}%</span>
                <div class="meter"><i style="width:{min(100.0, acc_val)}%"></i></div>
            </div>
            <div>
                <span class="lbl">Потеря за ход</span>
                <span class="fig">{selected_game.acpl or 0} <small class="unit">сантипешек</small></span>
            </div>
            <div>
                <span class="lbl">Ошибки в партии</span>
                <div class="marks">
                    {severity_mark('blunder', selected_game.blunders_count, with_label=False)}
                    {severity_mark('mistake', selected_game.mistakes_count, with_label=False)}
                    {severity_mark('inaccuracy', selected_game.inaccuracies_count, with_label=False)}
                </div>
            </div>
        </div>
        """)
        st.markdown("<div style='height:18px;'></div>", unsafe_allow_html=True)

        error_events = error_events_by_game.get(selected_game.id, [])

        # ================================================================
        # РЕЖИМ 1: ТРЕНАЖЁР ОШИБКИ — большая доска слева, разбор справа
        # ================================================================
        if board_mode == BOARD_MODE_TRAINER:
            col_board, col_side = st.columns([7, 5], gap="large")
            active_error: Optional[ChessErrorEvent] = None

            # Правая колонка заполняется первой: выбранная ошибка определяет позицию на доске.
            with col_side:
                if not error_events:
                    render_html(note_box("good", "Без серьёзных ошибок", "Движок не нашёл в этой партии зевков и ошибок. Доска свободна: можно разыгрывать любые позиции."))
                else:
                    err_options = {
                        f"Ход {e.move_number}. {figurine(e.played_move_san)}{SEVERITY_MARKS.get(e.severity, ('?',))[0]}  (−{e.centipawn_loss})": e
                        for e in error_events
                    }
                    selected_err_label = st.selectbox(f"Ключевые моменты: {len(error_events)}", options=list(err_options.keys()))
                    active_error = err_options[selected_err_label]

                    theme_info = PuzzleGeneratorService.get_theme_info(active_error.tactical_tag or "tactical_blunder")
                    clock = float(active_error.clock_remaining_seconds) if active_error.clock_remaining_seconds is not None else None
                    time_note = (
                        f'<span class="chip chip-loss">Цейтнот: {clock:g} с на часах</span>'
                        if active_error.is_time_trouble and clock is not None else
                        (f'<span class="lbl">На часах было {clock:g} с</span>' if clock is not None else "")
                    )

                    render_html(f"""
                    <div class="panel">
                        <div class="panel-row">
                            {severity_mark(active_error.severity)}
                            <span class="lbl">{phase_name(active_error.phase)}</span>
                        </div>
                        <div style="margin-top:12px; line-height:1.5;">
                            <span class="lbl">Тема</span><br>
                            <b>{short_theme_title(theme_info['title'])}</b>
                        </div>
                        <div class="stat-row">
                            <div>
                                <span class="lbl">Потеря</span>
                                <span class="fig" style="color:var(--flag);">−{active_error.centipawn_loss}</span>
                                <span class="lbl">сантипешек</span>
                            </div>
                            <div>
                                <span class="lbl">Шансы на победу</span>
                                <span class="fig" style="color:var(--amber);">−{round(float(active_error.win_rate_drop or 0) * 100, 1):g}%</span>
                            </div>
                        </div>
                        <div style="margin-top:12px;">{time_note}</div>
                    </div>
                    """)

            with col_board:
                if active_error:
                    base_fen = active_error.fen_before
                    err_id = active_error.id

                    # Сброс FEN при смене выбранной ошибки
                    if st.session_state.get("current_error_view_id") != err_id:
                        st.session_state["current_error_view_id"] = err_id
                        st.session_state[f"fen_{err_id}"] = base_fen
                        st.session_state[f"feedback_{err_id}"] = None
                        st.session_state[f"anim_{err_id}"] = False

                    current_fen = st.session_state.get(f"fen_{err_id}", base_fen)
                    animate_best = st.session_state.get(f"anim_{err_id}", False)

                    move_event = render_interactive_chessboard(
                        fen=current_fen,
                        orientation=selected_game.student_color,
                        allow_moves=True,
                        animate_best_move=animate_best,
                        best_move_uci=active_error.best_move_uci,
                        key=f"drag_board_{selected_game.id}_{err_id}"
                    )

                    # Обработка хода пользователя
                    if move_event and move_event.get("event") == "move_played":
                        ts = move_event.get("timestamp")
                        ts_key = f"last_ts_{err_id}"
                        if ts != st.session_state.get(ts_key):
                            st.session_state[ts_key] = ts
                            user_uci = move_event.get("uci")
                            user_san = move_event.get("san")
                            fen_after = move_event.get("fen_after")
                            st.session_state[f"fen_{err_id}"] = fen_after
                            st.session_state[f"anim_{err_id}"] = False

                            # Вариант А: ход из партии (повтор ошибки)
                            if user_uci == active_error.played_move_uci or user_san == active_error.played_move_san:
                                theme_info = PuzzleGeneratorService.get_theme_info(active_error.tactical_tag or "tactical_blunder")
                                glyph, label = SEVERITY_MARKS.get(active_error.severity, ("?", active_error.severity))
                                st.session_state[f"feedback_{err_id}"] = {
                                    "type": "bad",
                                    "title": f"Так и было сыграно в партии: {figurine(active_error.played_move_san)}{glyph}",
                                    "body": (
                                        f"<p>{label}: −{active_error.centipawn_loss} сантипешек, шансы на победу "
                                        f"падают на {round(float(active_error.win_rate_drop or 0) * 100, 1):g}%.</p>"
                                        f"<p>{theme_info['description']}</p>"
                                        f"<p>Нажмите «Вернуть позицию» и поищите другой ход.</p>"
                                    ),
                                }
                                st.rerun()

                            # Вариант Б: лучший ход движка
                            elif user_uci == active_error.best_move_uci or user_san == active_error.best_move_san:
                                st.session_state[f"feedback_{err_id}"] = {
                                    "type": "good",
                                    "title": f"Верно: {figurine(active_error.best_move_san)}!",
                                    "body": "Это первый выбор движка. Ход снимает угрозы соперника.",
                                }
                                st.rerun()

                            # Вариант В: другой ход — быстрая оценка движком
                            else:
                                student_color = chess.WHITE if selected_game.student_color == "white" else chess.BLACK
                                eval_res = ChessEngineAnalyzer.quick_evaluate_position(
                                    fen=fen_after,
                                    depth=10,
                                    time_limit=0.05,
                                    relative_color=student_color
                                )
                                st.session_state[f"feedback_{err_id}"] = {
                                    "type": "info",
                                    "title": f"Другой ход: {figurine(user_san)}",
                                    "body": (
                                        f"<p>Оценка движка: <b>{eval_res['score_formatted']}</b> (глубина {eval_res['depth']}).</p>"
                                        f"<p>{eval_res['verdict']}</p>"
                                    ),
                                }
                                st.rerun()
                else:
                    render_interactive_chessboard(
                        fen=chess.STARTING_FEN,
                        orientation=selected_game.student_color,
                        allow_moves=True,
                        key=f"free_board_{selected_game.id}"
                    )

            # Кнопки и обратная связь — под разбором ошибки, рядом с доской
            if active_error:
                with col_side:
                    c_btn1, c_btn2 = st.columns(2)
                    with c_btn1:
                        if st.button("Показать лучший ход", type="primary", use_container_width=True, key=f"btn_best_{err_id}"):
                            st.session_state[f"anim_{err_id}"] = True
                            st.session_state[f"feedback_{err_id}"] = {
                                "type": "good",
                                "title": f"Лучший ход: {figurine(active_error.best_move_san)}",
                                "body": "",
                            }
                            st.rerun()

                    with c_btn2:
                        if st.button("Вернуть позицию", use_container_width=True, key=f"btn_reset_{err_id}"):
                            st.session_state[f"fen_{err_id}"] = base_fen
                            st.session_state[f"anim_{err_id}"] = False
                            st.session_state[f"feedback_{err_id}"] = None
                            st.rerun()

                    fb = st.session_state.get(f"feedback_{err_id}")
                    if fb:
                        render_html(note_box(fb["type"], fb["title"], fb["body"]))
                        render_html(f"""
                        <div class="versus">
                            <div class="played"><span class="lbl">В партии</span><br><span class="san">{figurine(active_error.played_move_san)}</span></div>
                            <div class="best"><span class="lbl">Движок</span><br><span class="san">{figurine(active_error.best_move_san)}</span></div>
                        </div>
                        """)
                    else:
                        st.caption("Перетащите фигуру на доске, чтобы проверить свой ход. Движок сразу оценит его.")

                    st.link_button("Решать задачи на эту тему на Lichess", theme_info["url"], use_container_width=True)

        # ================================================================
        # РЕЖИМ 2: ПРОСМОТР ПАРТИИ — доска и бланк записи ходов
        # ================================================================
        else:
            plies = parse_game_plies(selected_game.pgn, error_events)

            render_interactive_chessboard(
                fen=plies[0]["fen"] if plies else chess.STARTING_FEN,
                orientation=selected_game.student_color,
                allow_moves=False,
                plies=plies,
                initial_ply=0,
                key=f"walk_board_{selected_game.id}"
            )

            # Навигация стрелками с любой части страницы
            render_html("""
            <script>
            (function() {
                if (!window._chessNavScriptLoaded) {
                    window._chessNavScriptLoaded = true;
                    window.addEventListener('keydown', function(e) {
                        if (e.key === 'ArrowLeft' || e.key === 'ArrowRight' || e.key === 'Home' || e.key === 'End') {
                            const iframes = document.querySelectorAll('iframe[title*="interactive_chessboard"]');
                            iframes.forEach(function(f) {
                                if (f && f.contentWindow) {
                                    f.contentWindow.postMessage({ type: 'nav_key', key: e.key }, '*');
                                }
                            });
                        }
                    });
                }
            })();
            </script>
            """)

            st.caption("Нажмите на ход в бланке или листайте стрелками ← → на клавиатуре. Ошибки отмечены красным.")

        if all_student_errors:
            worksheet_pdf = WorksheetPDFGenerator.generate_worksheet(
                student_name=student_display_name,
                error_events=all_student_errors,
                games=games_list,
                max_puzzles=4
            )
            st.download_button(
                label="Скачать лист задач по всем ошибкам (PDF, A4)",
                data=worksheet_pdf,
                file_name=f"ChessWorksheet_{student_display_name.replace(' ', '_')}.pdf",
                mime="application/pdf",
                key="btn_download_worksheet_tab1"
            )


# ----------------------------------------------------------------------------
# ВКЛАДКА 2: ПРОГРЕСС УЧЕНИКА
# ----------------------------------------------------------------------------
with tab_analytics:
    if not games_list:
        render_html(note_box("info", "Здесь появится статистика", "Загрузите хотя бы несколько партий ученика."))
    else:
        total_g = len(games_list)
        outcomes = [game_outcome(g) for g in games_list]
        wins_count = outcomes.count("win")
        draws_count = outcomes.count("draw")
        losses_count = outcomes.count("loss")
        score_pct = round((wins_count + 0.5 * draws_count) / total_g * 100, 1)

        valid_acc = [float(g.accuracy_score) for g in games_list if g.accuracy_score is not None]
        avg_acc = round(sum(valid_acc) / len(valid_acc), 1) if valid_acc else 0.0

        valid_acpl = [g.acpl for g in games_list if g.acpl is not None]
        avg_acpl = int(sum(valid_acpl) / len(valid_acpl)) if valid_acpl else 0

        all_errors = all_student_errors
        time_trouble_errors = sum(1 for e in all_errors if e.is_time_trouble)

        acc_class, acc_status = (
            ("good", "Высокий уровень") if avg_acc >= 85 else
            (("", "Стабильная игра") if avg_acc >= 75 else ("warn", "Нужна практика"))
        )
        acpl_status = "Уровень мастера" if avg_acpl <= 25 else ("Уровень КМС" if avg_acpl <= 45 else "Разрядный уровень")
        tt_class = "bad" if time_trouble_errors > 0 else "good"
        tt_note = f"из {len(all_errors)} ошибок" if all_errors else "ошибок не найдено"

        score_tone = "felt" if score_pct >= 50 else ("amber" if score_pct >= 35 else "flag")
        acc_tone = "felt" if avg_acc >= 75 else "amber"
        render_svg_html(f"""
        <div class="rings">
            <div>{ring(score_pct, "Набрано очков", f"+{wins_count} ={draws_count} −{losses_count} в {total_g} партиях", score_tone)}</div>
            <div>{ring(avg_acc, "Средняя точность", f'<span class="ring-sub {acc_class}">{acc_status}</span>', acc_tone)}</div>
            <div class="big-stat">
                <span class="lbl">Потеря за ход</span>
                <span class="fig">{avg_acpl} <small>сантипешек</small></span>
                <span class="note">{acpl_status}</span>
            </div>
            <div class="big-stat">
                <span class="lbl">Ошибок в цейтноте</span>
                <span class="fig">{time_trouble_errors}</span>
                <span class="note {tt_class}">{tt_note}</span>
            </div>
        </div>
        """)

        st.markdown("#### Точность от партии к партии")
        chrono = list(zip(games_list, outcomes))
        render_svg_html(accuracy_timeline([g for g, _ in chrono], [o for _, o in chrono]))

        g_col1, g_col2 = st.columns(2, gap="large")

        with g_col1:
            st.markdown("#### Где ошибается: по стадиям партии")
            phase_counts = {"Дебют": 0, "Миттельшпиль": 0, "Эндшпиль": 0}
            for e in all_errors:
                name = phase_name(e.phase)
                if name in phase_counts:
                    phase_counts[name] += 1

            fig_phases = go.Figure(go.Bar(
                x=list(phase_counts.keys()),
                y=list(phase_counts.values()),
                marker=dict(color=PALETTE["felt"], cornerradius=3, line=dict(width=0)),
                width=0.5,
                text=list(phase_counts.values()),
                textposition="outside",
                textfont=dict(color=PALETTE["ink"], family=SANS, size=13),
                cliponaxis=False,
                hovertemplate="<b>%{x}</b><br>Ошибок: %{y}<extra></extra>"
            ))
            layout = plotly_layout()
            layout["xaxis"].update(showgrid=False, tickfont=dict(color=PALETTE["ink"], size=13, family=SANS))
            layout["yaxis"].update(showgrid=True, dtick=1 if max(phase_counts.values()) <= 6 else None)
            fig_phases.update_layout(**layout)
            st.plotly_chart(fig_phases, use_container_width=True, config={"displayModeBar": False})

        with g_col2:
            st.markdown("#### Какие темы подводят")
            tag_counts: Dict[str, int] = {}
            for e in all_errors:
                title = short_theme_title(PuzzleGeneratorService.get_theme_info(e.tactical_tag or "tactical_blunder")["title"])
                tag_counts[title] = tag_counts.get(title, 0) + 1

            if tag_counts:
                # По возрастанию: самая частая тема окажется сверху горизонтального графика
                sorted_tags = sorted(tag_counts.items(), key=lambda x: x[1])
                labels = [item[0] for item in sorted_tags]
                values = [item[1] for item in sorted_tags]
                top = max(values)

                fig_tags = go.Figure(go.Bar(
                    x=values,
                    y=labels,
                    orientation="h",
                    marker=dict(
                        color=[PALETTE["flag"] if v == top else PALETTE["rule"] for v in values],
                        cornerradius=3,
                    ),
                    text=values,
                    textposition="outside",
                    textfont=dict(color=PALETTE["ink"], family=SANS, size=12),
                    cliponaxis=False,
                    hovertemplate="<b>%{y}</b><br>Ошибок: %{x}<extra></extra>"
                ))
                layout = plotly_layout(height=max(220, 44 * len(labels) + 40))
                layout["xaxis"].update(showgrid=False, showticklabels=False)
                layout["yaxis"].update(showgrid=False, tickfont=dict(color=PALETTE["ink"], size=12, family=SANS))
                fig_tags.update_layout(**layout)
                st.plotly_chart(fig_tags, use_container_width=True, config={"displayModeBar": False})
            else:
                st.caption("Тактических ошибок не найдено.")

        st.divider()

        # ====================================================================
        # ДЕБЮТНЫЙ РЕПЕРТУАР
        # ====================================================================
        st.markdown("### Дебютный репертуар")
        st.caption("Какие дебюты ученик играет, как в них набирает очки и где теряет позицию в первые 10–15 ходов.")

        repertoire_res = OpeningAnalyzerService.analyze_repertoire(
            games=games_list,
            student_name=student_display_name
        )

        if repertoire_res.repertoire_holes:
            render_html(note_box(
                "bad",
                f"Слабых мест в репертуаре: {len(repertoire_res.repertoire_holes)}",
                rich_text(repertoire_res.summary_insight),
            ))
        else:
            render_html(note_box("good", "Явных пробелов в дебютах нет", rich_text(repertoire_res.summary_insight)))

        REP_WHITE = f"Белыми ({len(repertoire_res.white_openings)})"
        REP_BLACK = f"Чёрными ({len(repertoire_res.black_openings)})"
        REP_HOLES = f"Только слабые места ({len(repertoire_res.repertoire_holes)})"
        rep_tab_choice = st.radio(
            "Показать дебюты",
            options=[REP_WHITE, REP_BLACK, REP_HOLES],
            horizontal=True,
            index=0 if repertoire_res.white_openings else (1 if repertoire_res.black_openings else 2),
            label_visibility="collapsed",
        )

        if rep_tab_choice == REP_WHITE:
            current_openings = repertoire_res.white_openings
        elif rep_tab_choice == REP_BLACK:
            current_openings = repertoire_res.black_openings
        else:
            current_openings = repertoire_res.repertoire_holes

        OPENING_STATUS = {
            "Критическая дыра": ("status-hole", "chip-loss", "Слабое место"),
            "Требует разбора": ("status-review", "chip-warn", "Стоит разобрать"),
        }

        if not current_openings:
            st.caption("В этой категории дебютов нет.")
        else:
            for op in current_openings:
                card_cls, chip_cls, status_label = OPENING_STATUS.get(op.status, ("status-ok", "chip-win", "Надёжно"))
                color_label = "белыми" if op.color == "white" else "чёрными"
                wr_color = "var(--felt)" if op.win_rate >= 50 else ("var(--amber)" if op.win_rate >= 40 else "var(--flag)")
                err_color = "var(--flag)" if op.early_blunders_count > 0 else ("var(--amber)" if op.early_errors_count > 0 else "var(--felt)")

                render_html(f"""
                <div class="panel opening {card_cls}">
                    <div class="panel-row">
                        <div>
                            <span class="chip chip-eco">{op.eco}</span>
                            <span class="name">&nbsp;{op.name}</span>
                            <div class="lbl" style="margin-top:4px;">Играет {color_label}</div>
                        </div>
                        <span class="chip {chip_cls}">{status_label}</span>
                    </div>
                    <div class="stat-row">
                        <div>
                            <span class="lbl">Партий</span>
                            <span class="fig">{op.games_count}</span>
                            <span class="wdl"><span class="w">+{op.wins}</span> ={op.draws} <span class="l">−{op.losses}</span></span>
                        </div>
                        <div>
                            <span class="lbl">Побед</span>
                            <span class="fig" style="color:{wr_color};">{op.win_rate:g}%</span>
                        </div>
                        <div>
                            <span class="lbl">Точность в дебюте</span>
                            <span class="fig">{op.opening_accuracy:g}%</span>
                            <span class="lbl">потеря {op.opening_acpl} за ход</span>
                        </div>
                        <div>
                            <span class="lbl">Ошибок до 15-го хода</span>
                            <span class="fig" style="color:{err_color};">{op.early_errors_count}</span>
                            <span class="lbl">из них зевков: {op.early_blunders_count}</span>
                        </div>
                    </div>
                    <div class="tip"><b>Совет тренеру.</b> {rich_text(op.coach_tip)}</div>
                </div>
                """)


# ----------------------------------------------------------------------------
# ВКЛАДКА 3: ОТЧЁТЫ
# ----------------------------------------------------------------------------
ROLE_COACH = "Для тренера"
ROLE_PARENT = "Для родителей"

with tab_ai:
    r_col1, r_col2 = st.columns([6, 4])
    with r_col1:
        st.markdown("### Отчёт по партиям")
        st.caption("Подробный разбор для тренера и понятное письмо для родителей, по одним и тем же партиям.")
    with r_col2:
        tab_ai_role = st.radio(
            "Для кого отчёт",
            options=[ROLE_COACH, ROLE_PARENT],
            horizontal=True,
            index=0,
            label_visibility="collapsed",
        )

    if not games_list:
        render_html(note_box("info", "Отчёт пока не из чего собрать", "Сначала загрузите партии ученика в панели слева."))
    else:
        agg_input = []
        for g in games_list:
            agg_input.append({
                "analysis": GameAnalysisResult(
                    accuracy_score=float(g.accuracy_score or 90.0),
                    acpl=g.acpl or 20,
                    blunders_count=g.blunders_count,
                    mistakes_count=g.mistakes_count,
                    inaccuracies_count=g.inaccuracies_count,
                    time_blunders_count=g.time_spent_blunders_count,
                    errors=[],
                    moves_tree=[]
                ),
                "student_color": g.student_color,
                "result": g.result,
                "opponent_username": g.opponent_username
            })

        aggregator = GameMetricsAggregator()
        stats = aggregator.aggregate(
            student_name=st.session_state.get("student_name", "Ученик"),
            period_description="Октябрь 2026",
            games_data=agg_input
        )

        c_act1, c_act2, c_act3 = st.columns([1, 1, 1], gap="medium")
        with c_act1:
            gen_report_btn = st.button("Составить отчёт", type="primary", use_container_width=True)

        if all_student_errors:
            worksheet_pdf_tab3 = WorksheetPDFGenerator.generate_worksheet(
                student_name=student_display_name,
                error_events=all_student_errors,
                games=games_list,
                max_puzzles=4
            )
            with c_act3:
                st.download_button(
                    label="Скачать лист задач (PDF)",
                    data=worksheet_pdf_tab3,
                    file_name=f"ChessWorksheet_{student_display_name.replace(' ', '_')}.pdf",
                    mime="application/pdf",
                    use_container_width=True,
                    key="btn_download_worksheet_tab3"
                )

        if gen_report_btn or "cached_coach_report" in st.session_state:
            reporter = LLMReporterService()

            if gen_report_btn:
                with st.spinner("Собираем отчёт по партиям…"):
                    st.session_state["cached_coach_report"] = reporter.generate_coach_report(stats)
                    st.session_state["cached_parent_report"] = reporter.generate_parent_report(stats)

            coach_rep = st.session_state.get("cached_coach_report")
            parent_rep = st.session_state.get("cached_parent_report")

            if parent_rep:
                pdf_bytes = PDFReportGenerator.generate_parent_pdf(
                    report=parent_rep,
                    stats=stats,
                    coach_name="Тренерский штаб"
                )
                with c_act2:
                    st.download_button(
                        label="Скачать отчёт для родителей (PDF)",
                        data=pdf_bytes,
                        file_name=f"ChessCoach_Report_{parent_rep.child_name.replace(' ', '_')}.pdf",
                        mime="application/pdf",
                        use_container_width=True
                    )

            st.divider()

            # ============================================================
            # ОТЧЁТ ДЛЯ ТРЕНЕРА
            # ============================================================
            if tab_ai_role == ROLE_COACH and coach_rep:
                render_html(note_box("info", f"Итог по партиям: {coach_rep.student_name}", rich_text(coach_rep.executive_summary)))

                st.markdown("#### Повторяющиеся ошибки")
                patterns_html = "".join(
                    f"""
                    <div class="pattern">
                        <div class="head">
                            <span class="title">{rich_text(p.title)}</span>
                            <span class="chip chip-loss">{rich_text(p.frequency)}</span>
                        </div>
                        <p>{rich_text(p.description)}</p>
                    </div>
                    """
                    for p in coach_rep.systemic_patterns
                )
                render_html(f'<div class="panel">{patterns_html}</div>')

                render_html(f"""
                <div class="panel">
                    <span class="lbl">Игра в цейтноте</span>
                    <div style="margin-top:4px; line-height:1.5;">{rich_text(coach_rep.time_trouble_verdict)}</div>
                </div>
                """)

                st.markdown("#### План следующих занятий")
                lessons_html = "".join(f"<li>{rich_text(lesson)}</li>" for lesson in coach_rep.next_lessons_plan)
                render_html(f'<ol class="lesson-plan">{lessons_html}</ol>')

                st.divider()
                st.markdown("#### Домашнее задание")
                st.caption("Подборки задач Lichess под темы, в которых ученик ошибался.")

                puzzle_recs = PuzzleGeneratorService.generate_recommendations(stats.top_tactical_weaknesses)
                for rec in puzzle_recs:
                    render_html(f"""
                    <div class="panel homework">
                        <div class="panel-row">
                            <span class="title">{short_theme_title(rec['title'])}</span>
                            <span class="chip">{rec['puzzles_recommended']} задач</span>
                        </div>
                        <div class="muted" style="margin-top:6px; line-height:1.5;">{rec['description']}</div>
                        <div class="small" style="margin-top:8px; color:var(--flag);">{rec['error_frequency']}</div>
                    </div>
                    """)
                    st.link_button(
                        f"Открыть задачи: {short_theme_title(rec['title'])}",
                        rec["url"],
                        use_container_width=True
                    )

                st.divider()
                st.markdown("#### Текст для мессенджера")
                st.caption("Скопируйте и отправьте себе или коллеге.")
                coach_text = (
                    f"Разбор партий: {coach_rep.student_name}\n\n"
                    f"{coach_rep.executive_summary}\n\n"
                    f"Повторяющиеся ошибки:\n" + "\n".join([f"- {p.title} ({p.frequency})" for p in coach_rep.systemic_patterns]) + "\n\n"
                    f"Задачи на дом (Lichess):\n" + "\n".join([f"- {r['title']}: {r['url']}" for r in puzzle_recs]) + "\n\n"
                    f"План занятий:\n" + "\n".join([f"- {l}" for l in coach_rep.next_lessons_plan])
                )
                st.code(coach_text, language="markdown")

            # ============================================================
            # ОТЧЁТ ДЛЯ РОДИТЕЛЕЙ
            # ============================================================
            elif tab_ai_role == ROLE_PARENT and parent_rep:
                render_html(note_box("good", f"Как прошла неделя: {parent_rep.child_name}", rich_text(parent_rep.greeting_and_summary)))

                st.markdown("#### Что получилось")
                achievements_html = "".join(f"<li>{rich_text(a)}</li>" for a in parent_rep.achievements)
                render_html(f'<ul class="report-list plus">{achievements_html}</ul>')

                st.markdown("#### Над чем работаем дальше")
                growth_html = "".join(f"<li>{rich_text(g)}</li>" for g in parent_rep.areas_for_growth)
                render_html(f'<ul class="report-list growth">{growth_html}</ul>')

                render_html(note_box("info", "Как поддержать дома", rich_text(parent_rep.home_support_advice)))

                st.divider()
                st.markdown("#### Сообщение для WhatsApp")
                st.caption("Готовый текст, который можно переслать родителям.")
                parent_text = (
                    f"{parent_rep.greeting_and_summary}\n\n"
                    f"Что получилось:\n" + "\n".join([f"+ {a}" for a in parent_rep.achievements]) + "\n\n"
                    f"Над чем работаем:\n" + "\n".join([f"- {g}" for g in parent_rep.areas_for_growth]) + "\n\n"
                    f"Как поддержать дома:\n{parent_rep.home_support_advice}"
                )
                st.code(parent_text, language="text")


# ----------------------------------------------------------------------------
# ВКЛАДКА 4: УЧЕНИКИ ТРЕНЕРА
# ----------------------------------------------------------------------------
GENDER_OPTIONS = list(coach_service.GENDERS.keys())
ACTION_ADD = "Добавить ученика"
ACTION_EDIT = "Изменить данные"


def student_form(form_key: str, student: Optional[coach_service.StudentView] = None) -> Optional[dict]:
    """Форма данных ученика. Возвращает введённые значения после нажатия кнопки."""
    with st.form(form_key, clear_on_submit=False):
        full_name = st.text_input("Имя и фамилия", value=student.full_name if student else "")
        g_col, a_col = st.columns(2)
        with g_col:
            gender = st.radio(
                "Пол",
                options=GENDER_OPTIONS,
                index=GENDER_OPTIONS.index(student.gender) if student and student.gender in GENDER_OPTIONS else None,
                format_func=coach_service.GENDERS.get,
                horizontal=True,
            )
        with a_col:
            age = st.number_input(
                "Возраст",
                min_value=coach_service.MIN_AGE,
                max_value=coach_service.MAX_AGE,
                value=student.age if student else None,
                step=1,
                placeholder="лет",
            )
        lichess = st.text_input(
            "Lichess",
            value=(student.accounts.get("lichess", "") if student else ""),
            placeholder="ник или ссылка lichess.org/@/…",
        )
        chesscom = st.text_input(
            "Chess.com",
            value=(student.accounts.get("chesscom", "") if student else ""),
            placeholder="ник или ссылка chess.com/member/…",
        )
        label = "Сохранить изменения" if student else "Добавить ученика"
        if st.form_submit_button(label, type="primary", use_container_width=True):
            return {"full_name": full_name, "gender": gender, "age": age, "lichess": lichess, "chesscom": chesscom}
    return None


with tab_students:
    roster_col, form_col = st.columns([7, 5], gap="large")

    with roster_col:
        st.markdown("### Мои ученики")
        if not students:
            render_html(note_box("info", "Список пока пуст", "Заполните форму справа, чтобы добавить первого ученика."))
        else:
            rows = "".join(
                f"""
                <tr class="{'is-current' if current_student and s.id == current_student.id else ''}">
                    <td class="name">{html.escape(s.full_name)}</td>
                    <td>{coach_service.GENDERS.get(s.gender, '—')}</td>
                    <td>{age_label(s.age) or '—'}</td>
                    <td>{html.escape(s.accounts.get('lichess', '—'))}</td>
                    <td>{html.escape(s.accounts.get('chesscom', '—'))}</td>
                    <td class="num">{s.games_count}</td>
                </tr>"""
                for s in students
            )
            render_html(f"""
            <div class="roster-wrap"><table class="roster">
                <thead><tr><th>Ученик</th><th>Пол</th><th>Возраст</th><th>Lichess</th><th>Chess.com</th><th class="num">Партий</th></tr></thead>
                <tbody>{rows}</tbody>
            </table></div>
            """)
            st.caption("Ученик, выбранный слева, выделен. Его партии и прогресс показаны на других вкладках.")

    with form_col:
        action = st.radio(
            "Действие",
            options=[ACTION_ADD, ACTION_EDIT] if students else [ACTION_ADD],
            horizontal=True,
            label_visibility="collapsed",
        )

        if action == ACTION_ADD:
            # Новый ключ формы после успешного сохранения даёт пустую форму;
            # при ошибке ключ тот же, и введённые данные не теряются.
            form_version = st.session_state.get("add_form_version", 0)
            values = student_form(f"add_student_{form_version}")
            if values:
                try:
                    new_id = coach_service.save_student(coach.id, **values)
                    st.session_state["student_id"] = new_id
                    st.session_state["add_form_version"] = form_version + 1
                    flash("success", f"Ученик {values['full_name'].strip()} добавлен.")
                    st.rerun()
                except coach_service.ValidationError as exc:
                    st.error(str(exc))
        else:
            by_id = {s.id: s for s in students}
            default_id = current_student.id if current_student else students[0].id
            edit_id = st.selectbox(
                "Кого изменить",
                options=list(by_id.keys()),
                index=list(by_id.keys()).index(default_id),
                format_func=lambda sid: by_id[sid].full_name,
            )
            values = student_form(f"edit_student_{edit_id}", by_id[edit_id])
            if values:
                try:
                    coach_service.save_student(coach.id, student_id=edit_id, **values)
                    flash("success", "Изменения сохранены.")
                    st.rerun()
                except coach_service.ValidationError as exc:
                    st.error(str(exc))

            with st.expander("Удалить ученика"):
                st.caption("Вместе с учеником удалятся все его партии и разбор ошибок. Отменить это нельзя.")
                confirm = st.checkbox(f"Да, удалить {by_id[edit_id].full_name}", key=f"confirm_delete_{edit_id}")
                if st.button("Удалить", disabled=not confirm, key=f"delete_{edit_id}"):
                    coach_service.delete_student(coach.id, edit_id)
                    reset_student_state()
                    flash("success", f"Ученик {by_id[edit_id].full_name} удалён.")
                    st.rerun()
