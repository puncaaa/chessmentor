"""Тесты сервиса тренеров и учеников (запуск: pytest test_coach_service.py)."""
import pytest

import app.db.session as db
from app.models.chess import Base
from app.services import coach_service as cs
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker


@pytest.fixture(autouse=True)
def fresh_db(monkeypatch):
    """Каждый тест работает с чистой базой в памяти."""
    engine = create_engine("sqlite://", connect_args={"check_same_thread": False})
    Base.metadata.create_all(engine)
    monkeypatch.setattr(db, "SessionLocal", sessionmaker(bind=engine, expire_on_commit=False))


def test_password_hash_roundtrip():
    stored = cs.hash_password("secret1")
    assert cs.verify_password("secret1", stored)
    assert not cs.verify_password("wrong", stored)


def test_login_and_coach_sees_only_own_students():
    alan = cs.create_coach("Alan", "alan123")
    aisara = cs.create_coach("Aisara", "aisara123")
    cs.save_student(alan.id, "Alikhan Serikov", "male", 11, lichess="alikhan_chess")
    cs.save_student(aisara.id, "Kamal Nurlanov", "male", 12)

    assert cs.authenticate(alan.id, "alan123").full_name == "Alan"
    assert cs.authenticate(alan.id, "nope") is None
    assert [s.full_name for s in cs.list_students(alan.id)] == ["Alikhan Serikov"]
    assert [s.full_name for s in cs.list_students(aisara.id)] == ["Kamal Nurlanov"]


def test_profile_links_are_turned_into_usernames():
    assert cs.normalize_username("lichess", "https://lichess.org/@/DrNykterstein") == "DrNykterstein"
    assert cs.normalize_username("chesscom", "https://www.chess.com/member/hikaru/") == "hikaru"
    assert cs.normalize_username("chesscom", "  ") is None
    with pytest.raises(cs.ValidationError):
        cs.normalize_username("lichess", "not a nick!")


def test_validation_errors():
    coach = cs.create_coach("Alan", "alan123")
    with pytest.raises(cs.ValidationError):
        cs.save_student(coach.id, "  ", "male", 10)
    with pytest.raises(cs.ValidationError):
        cs.save_student(coach.id, "Didar", "male", 2)
    with pytest.raises(cs.ValidationError):
        cs.create_coach("alan", "another1")  # имя уже занято
    with pytest.raises(cs.ValidationError):
        cs.create_coach("Bob", "123")  # слишком короткий пароль


def test_same_account_cannot_belong_to_two_students():
    coach = cs.create_coach("Alan", "alan123")
    cs.save_student(coach.id, "Sagi", "male", 10, lichess="sagi_k")
    with pytest.raises(cs.ValidationError):
        cs.save_student(coach.id, "Didar", "male", 10, lichess="SAGI_K")


def test_edit_and_unlink_account_and_delete():
    coach = cs.create_coach("Alan", "alan123")
    sid = cs.save_student(coach.id, "Diana", "female", 9, lichess="diana_l", chesscom="diana_c")
    cs.save_student(coach.id, "Diana Akhmetova", "female", 10, lichess="diana_l", chesscom="", student_id=sid)
    [diana] = cs.list_students(coach.id)
    assert (diana.full_name, diana.age, diana.accounts) == ("Diana Akhmetova", 10, {"lichess": "diana_l"})

    other = cs.create_coach("Aisara", "aisara123")
    with pytest.raises(cs.ValidationError):
        cs.delete_student(other.id, sid)  # чужого ученика удалить нельзя
    cs.delete_student(coach.id, sid)
    assert cs.list_students(coach.id) == []
