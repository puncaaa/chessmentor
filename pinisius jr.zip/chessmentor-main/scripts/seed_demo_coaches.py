"""Демо-данные: тренеры Alan и Aisara с учениками.

Запуск из корня проекта:
    python scripts/seed_demo_coaches.py

Скрипт можно запускать повторно: существующих тренеров и учеников он пропускает.
Пароли демо-тренеров: alan123 и aisara123. Ники на Lichess / Chess.com
не заполнены: впишите настоящие во вкладке «Ученики».
"""
import os
import sys

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from app.db.session import init_db
from app.services import coach_service

DEMO = {
    ("Alan", "alan123"): [
        ("Alikhan", "male", 11),
        ("Sagi", "male", 12),
        ("Didar", "male", 10),
        ("Johnny", "male", 13),
        ("Diana", "female", 11),
    ],
    ("Aisara", "aisara123"): [
        ("Sherkhan", "male", 9),
        ("Kamal", "male", 12),
        ("Danial", "male", 10),
    ],
}


def main() -> None:
    init_db()
    existing = {c.full_name: c for c in coach_service.list_coaches()}
    for (name, password), students in DEMO.items():
        coach = existing.get(name) or coach_service.create_coach(name, password)
        already = {s.full_name for s in coach_service.list_students(coach.id)}
        for full_name, gender, age in students:
            if full_name not in already:
                coach_service.save_student(coach.id, full_name, gender, age)
        print(f"{name}: учеников — {len(coach_service.list_students(coach.id))}")


if __name__ == "__main__":
    main()
